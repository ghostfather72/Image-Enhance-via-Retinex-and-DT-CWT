function image_info_plot(I, rgb, vargin)
% ��ͼ
figure,
subplot(231), imhist(double(I(:,:,1)) / 255), title('R of Original');
subplot(232), imhist(double(I(:,:,2)) / 255), title('G of Original');
subplot(233), imhist(double(I(:,:,3)) / 255), title('B of Original');
subplot(234), imhist(rgb(:,:,1)), title(['R of ' vargin]);
subplot(235), imhist(rgb(:,:,2)), title(['G of ' vargin]);
subplot(236), imhist(rgb(:,:,3)), title(['B of ' vargin]);

figure,
subplot(221),
imshow(imresize(I, 0.5)), title('Original Image')
subplot(222)
imhist(double(I(:,:,1)) / 255);
hold on
imhist(double(I(:,:,2)) / 255);
imhist(double(I(:,:,3)) / 255);
title('Original Image')
hold off
subplot(223)
imshow(imresize(rgb, 0.5)), title(vargin)
subplot(224)
imhist(rgb(:,:,1));
hold on
imhist(rgb(:,:,2));
imhist(rgb(:,:,3));
title(vargin)
hold off