vargin=('whitehouse.png');
I=image_load(vargin);
%figure,imshow(I),title('Original Image')
%figure,Histogram(I);title('Statistic Histogram of Original Image')
%Ir=double(I(:,:,1));
%Ig=double(I(:,:,2));
%Ib=double(I(:,:,3));
[H, S, V] = rgb2hsv(I);
V = V * 255;

% Global Adaptation
%Lw=0.299*Ir+0.587*Ig+0.114*Ib;% input world luminance values
Lw = V;

%figure,imshow(Lw/255)%,title('Luminance')
%[m,n]=size(Lw);
%figure,hist(reshape(Lw,1,m*n),255);

Lwmax=max(max(Lw));% the maximum luminance value
[m,n]=size(Lw);
Lwaver=exp(sum(sum(log(0.001+Lw)))/(m*n));% log-average luminance
Lg=log(Lw/Lwaver+1)/log(Lwmax/Lwaver+1);
%figure,imshow(Lg)%,title('Global Adaptation Output')

% Local Adaptation
Hg=guidedfilter(Lg,Lg,10,0.01);
%figure,imshow(Hg)
Li=log(Lg*255+1)-log(Hg*255+1);

eta=36;
alpha=1+eta*Lg/max(max(Lg));
Lgaver=exp(sum(sum(log(0.001+Lg)))/(m*n));
lambda=10;
beta=lambda*Lgaver;

Lout=alpha.*log(Lg./Hg+beta);
Min=min(min(Lout));
Max=max(max(Lout));
Lout=(Lout-Min)/(Max-Min);
n_b=find(Lout>1);
Lout(n_b)=1;
m_b=find(Lout<0);
Lout(m_b)=0;

a = 4;
Lout = 2 * atan(a * Lout) / pi;
Lout = adapthisteq(Lout, 'NumTiles', [8, 8], 'ClipLimit', 0.01,...
    'NBins', 256, 'Range', 'full', 'Distribution', 'exponential',...
    'Alpha', 0.4);
Lout = SimplestColorBalance(Lout * 255, 0.02);
Lout = Lout / 255;

rgb = hsv2rgb(cat(3, H, S, Lout));
figure,imshow(I)
figure,imshow(rgb)
figure,Histogram(double(I))
figure,Histogram(rgb * 255)

%figure,imshow(Lout/255)%,title('Final Local Adaptation Output')
%figure,hist(reshape(Lout,1,m*n),255);
%gain=Lout./Lw;
%[m,n]=size(gain);
%for i=1:m
%    for j=1:n
%        if Lw(i,j)==0
%            gain(i,j)=Lout(i,j);
%            %gain(i,j)=255;
%        end
%    end
%end
%a = 0.04;
%Irout=gain.*Ir;
%Irout = 2 * atan(a * Irout) / pi;
%Irout = adapthisteq(Irout / 255, 'NumTiles', [8, 8], 'ClipLimit', 0.02,...
%    'NBins', 256, 'Range', 'full', 'Distribution', 'exponential',...
%    'Alpha', 0.4);
%Igout=gain.*Ig;
%Igout = 2 * atan(a * Igout) / pi;
%Igout = adapthisteq(Igout / 255, 'NumTiles', [8, 8], 'ClipLimit', 0.02,...
%    'NBins', 256, 'Range', 'full', 'Distribution', 'exponential',...
%    'Alpha', 0.4);
%Ibout=gain.*Ib;
%Ibout = 2 * atan(a * Ibout) / pi;
%Ibout = adapthisteq(Ibout / 255, 'NumTiles', [8, 8], 'ClipLimit', 0.02,...
%    'NBins', 256, 'Range', 'full', 'Distribution', 'exponential',...
%    'Alpha', 0.4);
%altmr=cat(3,Irout,Igout,Ibout);
%figure,imshow(altmr / 255)
%figure,Histogram(altmr)
%altmr = SimplestColorBalance(altmr, 0.04);
%figure,imshow(altmr / 255),title('ALTM Retinex Output')
%figure,Histogram(altmr);title('Statistic Histogram of the Output')