vargin='Original2.png';
%I=image_load(vargin);
I = imread(vargin);
%I = imread('Original2.png');
%ref = imread('Reference2.png');
%figure,imshow(I),title('Original Image')
%figure,Histogram(I);title('Statistic Histogram of Original Image')
Ir=double(I(:,:,1));
Ig=double(I(:,:,2));
Ib=double(I(:,:,3));

% Global Adaptation
Lw=0.299*Ir+0.587*Ig+0.114*Ib;% input world luminance values

%figure,imshow(Lw/255)%,title('Luminance')
%[m,n]=size(Lw);
%figure,hist(reshape(Lw,1,m*n),255);

Lwmax=max(max(Lw));% the maximum luminance value
[m,n]=size(Lw);
Lwaver=exp(sum(sum(log(0.001+Lw)))/(m*n));% log-average luminance
Lg=log(Lw/Lwaver+1)/log(Lwmax/Lwaver+1);
%figure,imshow(Lg / max(max(Lg)))%,title('Global Adaptation Output')

% Local Adaptation
Hg=guidedfilter(Lg,Lg,10,0.01);
%figure,imshow(Hg)
Li=log(Lg*255+1)-log(Hg*255+1);

eta=36;
alpha=1+eta*Lg/max(max(Lg));
%figure,imshow(alpha / max(max(alpha)))
%alpha = alpha .* (alpha .^ (1 ./ alpha));
%b = max(max(alpha));
%figure,imshow(alpha / max(max(alpha)))
%a = 1.2;
%alpha = 2 * atan(a * alpha / b) / pi * b;
Lgaver=exp(sum(sum(log(0.001+Lg)))/(m*n));
lambda=10;
beta=lambda*Lgaver;

Lout=alpha.*log(Lg./Hg+beta);
%figure,imshow(Lout)
%max(max(Lout))
%min(min(Lout))
Min=min(min(Lout));
Max=max(max(Lout));
Lout=(Lout-Min)*255/(Max-Min);
n_b=find(Lout>255);
Lout(n_b)=255;
m_b=find(Lout<0);
Lout(m_b)=0;

figure,imshow(Lout/ max(max(Lout)))%,title('Final Local Adaptation Output')
%figure,hist(reshape(Lout,1,m*n),255);
gain=Lout./Lw;
[m,n]=size(gain);
for i=1:m
    for j=1:n
        if Lw(i,j)==0
            gain(i,j)=Lout(i,j);
            %gain(i,j)=255;
        end
    end
end
a = 0.04;
Irout=gain.*Ir;
%Irout = 2 * atan(a * Irout) / pi;
%Irout = adapthisteq(Irout / 255, 'NumTiles', [8, 8], 'ClipLimit', 0.02,...
%    'NBins', 256, 'Range', 'full', 'Distribution', 'exponential',...
%    'Alpha', 0.4);
Igout=gain.*Ig;
%Igout = 2 * atan(a * Igout) / pi;
%Igout = adapthisteq(Igout / 255, 'NumTiles', [8, 8], 'ClipLimit', 0.02,...
%    'NBins', 256, 'Range', 'full', 'Distribution', 'exponential',...
%    'Alpha', 0.4);
Ibout=gain.*Ib;
%Ibout = 2 * atan(a * Ibout) / pi;
%Ibout = adapthisteq(Ibout / 255, 'NumTiles', [8, 8], 'ClipLimit', 0.02,...
%    'NBins', 256, 'Range', 'full', 'Distribution', 'exponential',...
%    'Alpha', 0.4);
altmr=cat(3,Irout,Igout,Ibout);
%[SSIMVAL, ~] = ssim(uint8(altmr), uint8(ref))
%figure,imshow(I)
figure,imshow(altmr / 255)
%tt = (mean2(altmr(:,:,1))+mean2(altmr(:,:,2))+mean2(altmr(:,:,3)))/3
%dd = (std2(altmr(:,:,1))+std2(altmr(:,:,2))+std2(altmr(:,:,3)))/3
%figure,imshow(altmr / 255)
%figure,Histogram(altmr)
%altmr = SimplestColorBalance(altmr, 0.04);
%figure,imshow(altmr / 255),title('ALTM Retinex Output')
%figure,Histogram(altmr);title('Statistic Histogram of the Output')
%imwrite(uint8(altmr),'altmr.png');
%vif = vifvec(ref1,altmr1)
%figure, imhist(altmr(:,:,1) / 255)
%hold on 
%imhist(altmr(:,:,2) / 255)
%imhist(altmr(:,:,3) / 255)