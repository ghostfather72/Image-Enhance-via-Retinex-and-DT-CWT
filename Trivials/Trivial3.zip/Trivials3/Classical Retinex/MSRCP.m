%vargin='liahthouse.png';
%I=image_load(vargin);
I = imread('Original2.png');
ref = imread('Reference2.png');
if ndims(I) == 3
    Ir_double=double(I(:,:,1));
    Ig_double=double(I(:,:,2));
    Ib_double=double(I(:,:,3));
else
    Ir_double=double(I);
    Ig_double=double(I);
    Ib_double=double(I);
end
Int=(Ir_double+Ig_double+Ib_double)/3;
%figure,imshow(Int/255),title('Int')
[m,n]=size(Int);
alpha=125;
beta=46;
gain=30;
offset=-6;
cut=2.45;
sigma1=15;
sigma2=80;
sigma3=250;
F1=fspecial('gaussian',[3*sigma1,3*sigma1],sigma1);
F2=fspecial('gaussian',[3*sigma2,3*sigma2],sigma2);
F3=fspecial('gaussian',[3*sigma3,3*sigma3],sigma3);
L1=imfilter(Int,F1,'replicate','conv');
L2=imfilter(Int,F2,'replicate','conv');
L3=imfilter(Int,F3,'replicate','conv');
G=double(1/3)*(log(Int+1)-log(L1+1))+...
    double(1/3)*(log(Int+1)-log(L2+1))+...
    double(1/3)*(log(Int+1)-log(L3+1));
%figure,imshow(G),title('G')
Int1=SimplestColorBalance(G);
%C=beta*(log((Int+1)*alpha)-log(3*Int+3));
%G=gain*(C.*G+offset);
%u=mean2(G);%����ͼ��ľ�ֵ
%s=std2(G);%����
%Min=u-cut*s;%��Сֵ
%Max=u+cut*s;%���ֵ
%Int1=(G-Min)*255/(Max-Min);
%Int1(find(Int1>255))=255;
%Int1(find(Int1<0))=0;
%figure,imshow(Int1/255),title('Int1')
msrcp_r=zeros(m,n);
msrcp_g=zeros(m,n);
msrcp_b=zeros(m,n);
B=max(max(Ir_double,Ig_double),Ib_double);
A=min((255./B),(Int1./Int));
for i=1:m
    for j=1:n
        msrcp_r(i,j)=A(i,j)*Ir_double(i,j);
        msrcp_g(i,j)=A(i,j)*Ig_double(i,j);
        msrcp_b(i,j)=A(i,j)*Ib_double(i,j);
    end
end
%msrcp_r=msrcp_r/255;
%msrcp_g=msrcp_g/255;
%msrcp_b=msrcp_b/255;
msrcp=cat(3,msrcp_r,msrcp_g,msrcp_b);
[SSIMVAL, ~] = ssim(uint8(msrcp), uint8(ref))
%figure,imshow(msrcp/255);
%outval=evaluate(msrcp,double(I))