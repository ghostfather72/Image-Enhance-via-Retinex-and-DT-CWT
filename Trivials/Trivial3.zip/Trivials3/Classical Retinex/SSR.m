
vargin='memorial-original.jpg';
I=image_load(vargin);
vargin='memorial-reference.jpg';
ref=image_load(vargin);
%figure(1),imshow(I);
%I = imread('Original2.png');
%ref = imread('Reference2.png');
if ndims(I) == 3
    Ir_double=double(I(:,:,1));
    Ig_double=double(I(:,:,2));
    Ib_double=double(I(:,:,3));
else
    Ir_double=double(I);
    Ig_double=double(I);
    Ib_double=double(I);
end
%[m,n]=size(Ir_double);
sigma=15;
F=fspecial('gaussian',[3*sigma,3*sigma],sigma);%���ɸ�˹����
%*************R channel**************
L=imfilter(Ir_double,F,'replicate','conv');
%figure,imshow(L/255)
G=log(Ir_double+1)-log(L+1);
%figure,imshow(G)
Min=min(min(G));
Max=max(max(G));
Rr=(G-Min)*255/(Max-Min);
Rr(find(Rr>255))=255;
Rr(find(Rr<0))=0;
%*************G channel**************
L=imfilter(Ig_double,F,'replicate','conv');
G=log(Ig_double+1)-log(L+1);
Min=min(min(G));
Max=max(max(G));
Rg=(G-Min)*255/(Max-Min);
Rg(find(Rg>255))=255;
Rg(find(Rg<0))=0;
%*************B channel**************
L=imfilter(Ib_double,F,'replicate','conv');
G=log(Ib_double+1)-log(L+1);
Min=min(min(G));
Max=max(max(G));
Rb=(G-Min)*255/(Max-Min);
Rb(find(Rb>255))=255;
Rb(find(Rb<0))=0;

%Rr=Rr/255;
%Rg=Rg/255;
%Rb=Rb/255;
ssr=cat(3,Rr,Rg,Rb);
%figure,imshow(I)
figure,imshow(ssr / 255)
outval=image_evaluate(ssr,I)
figure,imhist(ssr(:,:,1)/255)
hold on
imhist(ssr(:,:,2)/255)
imhist(ssr(:,:,3)/255)
hold off
%figure(2),imshow(ssr/255);
%[SSIMVAL, ~] = ssim(uint8(ssr), uint8(ref))