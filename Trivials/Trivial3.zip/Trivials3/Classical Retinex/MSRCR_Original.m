vargin='whitehouse.png';
I=image_load(vargin);
%vargin='greenwich-reference.png';
%ref=image_load(vargin);
%figure,imshow(I);
%I = imread('Original2.png');
%ref = imread('Reference2.png');
if ndims(I) == 3
    Ir_double=double(I(:,:,1));
    Ig_double=double(I(:,:,2));
    Ib_double=double(I(:,:,3));
else
    Ir_double=double(I);
    Ig_double=double(I);
    Ib_double=double(I);
end
[m,n]=size(Ir_double);
figure,imshow(Ir_double / 255)
alpha=125;
beta=46;
gain=30;
offset=-6;
cut=2.45;
sigma1=double(15);
sigma2=double(80);
sigma3=double(250);
F1=fspecial('gaussian',[3*sigma1,3*sigma1],sigma1);
F2=fspecial('gaussian',[3*sigma2,3*sigma2],sigma2);
F3=fspecial('gaussian',[3*sigma3,3*sigma3],sigma3);
%*************R channel**************
L1=imfilter(Ir_double,F1,'replicate','conv');
figure,imshow(L1 / max(max(L1)))
L2=imfilter(Ir_double,F2,'replicate','conv');
figure,imshow(L2 / max(max(L2)))
L3=imfilter(Ir_double,F3,'replicate','conv');
figure,imshow(L3 / max(max(L3)))
G=double(1/3)*(log(Ir_double+1)-log(L1+1))+...
    double(1/3)*(log(Ir_double+1)-log(L2+1))+...
    double(1/3)*(log(Ir_double+1)-log(L3+1));
C=beta*(log((Ir_double+1)*alpha)-log(Ir_double+Ig_double+Ib_double+3));
G=gain*(C.*G+offset);
u=mean2(G);%����ͼ��ľ�ֵ
s=std2(G);%����
Min=u-cut*s;%��Сֵ
Max=u+cut*s;%���ֵ
Rr=(G-Min)*255/(Max-Min);
Rr(find(Rr>255))=255;
Rr(find(Rr<0))=0;
%*************G channel**************
L1=imfilter(Ig_double,F1,'replicate','conv');
L2=imfilter(Ig_double,F2,'replicate','conv');
L3=imfilter(Ig_double,F3,'replicate','conv');
G=double(1/3)*(log(Ig_double+1)-log(L1+1))+...
    double(1/3)*(log(Ig_double+1)-log(L2+1))+...
    double(1/3)*(log(Ig_double+1)-log(L3+1));
C=beta*(log((Ig_double+1)*alpha)-log(Ir_double+Ig_double+Ib_double+3));
G=gain*(C.*G+offset);
u=mean2(G);%����ͼ��ľ�ֵ
s=std2(G);%����
Min=u-cut*s;%��Сֵ
Max=u+cut*s;%���ֵ
Rg=(G-Min)*255/(Max-Min);
Rg(find(Rg>255))=255;
Rg(find(Rg<0))=0;
figure,imshow(Rg / 255)
%*************B channel**************
L1=imfilter(Ib_double,F1,'replicate','conv');
L2=imfilter(Ib_double,F2,'replicate','conv');
L3=imfilter(Ib_double,F3,'replicate','conv');
G=double(1/3)*(log(Ib_double+1)-log(L1+1))+...
    double(1/3)*(log(Ib_double+1)-log(L2+1))+...
    double(1/3)*(log(Ib_double+1)-log(L3+1));
C=beta*(log((Ib_double+1)*alpha)-log(Ir_double+Ig_double+Ib_double+3));
G=gain*(C.*G+offset);
u=mean2(G);%����ͼ��ľ�ֵ
s=std2(G);%����
Min=u-cut*s;%��Сֵ
Max=u+cut*s;%���ֵ
Rb=(G-Min)*255/(Max-Min);
Rb(find(Rb>255))=255;
Rb(find(Rb<0))=0;

%Rr=Rr/255;
%Rg=Rg/255;
%Rb=Rb/255;
msrcr=cat(3,Rr,Rg,Rb);
figure,imshow(msrcr)
imwrite(uint8(msrcr),'msrcr.png');
%PSNR = psnr(uint8(msrcr), uint8(ref))
%[SSIMVAL, ~] = ssim(uint8(msrcr), uint8(ref))
%[FSIM, ~] = FeatureSIM(uint8(ref), uint8(msrcr))
%msrcr1 = rgb2gray(uint8(msrcr));
%ref1 = rgb2gray(uint8(ref));
%vif = vifvec(ref1,msrcr1)