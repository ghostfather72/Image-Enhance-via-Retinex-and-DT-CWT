Img=imread('test1.jpg');
figure(1), 
imshow(Img), title('Original Image');

ssr=SSR(Img);
figure(2), 
imshow(ssr), title('SSR with sigma = 80');

msr=MSR(Img);
figure(3), 
imshow(msr), title('MSR with sigma = 15, 80, 250');

msrcr=MSRCR_Original(Img);
figure(4), 
imshow(msrcr), title('MSRCR with sigma = 15, 80, 250');

msrcp=MSRCP(Img);
figure(5), 
imshow(msrcp), title('MSRCP with sigma = 15, 80, 250');

figure(6)
II=imread('liahthouse_PS.png');
imshow(II), title('Image Processing by Photoshop');

I=double(Img)/255;
figure(7)
subplot(2,3,1)
Histogram(I); title('Original')
subplot(2,3,2)
Histogram(ssr); title('SSR')
subplot(2,3,3)
Histogram(msr); title('MSR')
subplot(2,3,4)
Histogram(msrcr); title('MSRCR')
subplot(2,3,5)
Histogram(msrcp); title('MSRCP')
II=double(II)/255;
subplot(2,3,6)
Histogram(II); title('Photoshop')