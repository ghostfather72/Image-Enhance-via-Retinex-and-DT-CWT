function XN=NeiX(X)
[s,t,K]=size(X);
% ����X��8����������ͼ��
Xul=zeros(s,t,K); % upper-left
Xul(2:s,2:t,:)=X(1:s-1,1:t-1,:);
Xu=zeros(s,t,K); % upper
Xu(2:s,:,:)=X(1:s-1,:,:);
Xur=zeros(s,t,K); % upper-right
Xur(2:s,1:t-1,:)=X(1:s-1,2:t,:);
Xr=zeros(s,t,K); % right
Xr(:,1:t-1,:)=X(:,2:t,:);
Xdr=zeros(s,t,K); % down-right
Xdr(1:s-1,1:t-1,:)=X(2:s,2:t,:);
Xd=zeros(s,t,K); % down
Xd(1:s-1,:,:)=X(2:s,:,:);
Xdl=zeros(s,t,K); % down-left
Xdl(1:s-1,2:t,:)=X(2:s,1:t-1,:);
Xl=zeros(s,t,K); % left
Xl(:,2:t,:)=X(:,1:t-1,:);
XN=cat(3,Xul,Xu,Xur,Xr,Xdr,Xd,Xdl,Xl);
end