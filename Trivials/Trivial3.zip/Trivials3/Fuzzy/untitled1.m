addpath(genpath('DT-CWT'))
addpath(genpath('HFEnhancement'))
vargin = 'lena.png';
I = image_load(vargin);
[H,S,V] = rgb2hsv(I);
[Faf, Fsf] = FSfarras;
[af, sf] = dualfilt1;
J = 1;
w = cplxdual2D(V, J, Faf, af);

for s = 1 : 2
    for s1 = 1 : 2
        for s2 = 1 : 3
            D = w{J}{s}{s1}{s2};
            D = D / max(max(D));
            %outval = FuzzyEnhance(D);
            outval = HFEnphasizeFilter(D);
            w{J}{s}{s1}{s2} = outval;
            %figure,imshow(outval)
            %figure,imshow(D*4)
            %D = w{J}{s}{s1}{s2};
            %figure,imshow(D / max(max(D)))
        end
    end
end
Imag = sqrt(-1);
T = 90 / 255;
for j = 1 : J
    for s1 = 1 : 2
        for s2 = 1 : 3
            D = w{j}{1}{s1}{s2} + Imag * w{j}{2}{s1}{s2};
            %D = HFEnphasizeFilter(D);
            D = soft(D, T);
            w{j}{1}{s1}{s2} = real(D);
            w{j}{2}{s1}{s2} = imag(D);
            figure,imshow(real(D)*5)
            figure,imshow(imag(D)*5)
        end
    end
end
%D = w{J}{2}{1}{1};%7
%D = D / max(max(D));
%outval = FuzzyEnhance(D);
%figure,imshow(outval)
%outval = HFEnphasizeFilter(D);
%figure,imshow(outval)
%D = w{J}{2}{1}{2};%8,10,11
%D = D / max(max(D));
%outval = FuzzyEnhance(D);
%figure,imshow(outval)

%D = w{J}{1}{1}{2};
%D = D / max(max(D));
%figure,imshow(D*4)
%outval = FuzzyEnhance(D);
%figure,imshow(outval)


rmpath 'DT-CWT'