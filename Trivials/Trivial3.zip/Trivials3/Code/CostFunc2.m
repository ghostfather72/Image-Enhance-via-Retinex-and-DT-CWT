function [ cost ] = CostFunc2( L,SS,alpha)
%COSTFUNC2 Summary of this function goes here
%   Detailed explanation goes here

KLAP = [ 0  1 0;
         1 -4 1;
         0  1 0];
     
FirstTerm = imfilter(L,KLAP,'symmetric'); 
FirstTerm = -L.*FirstTerm;
FirstTerm = sum(sum(FirstTerm));

SecondTerm = (L-SS).*(L-SS);
SecondTerm = sum(sum(SecondTerm));     

cost = FirstTerm + alpha*SecondTerm;
end
