function [ L ] = Envelope(L,SS)
%ENVELOPE Summary of this function goes here
%   Detailed explanation goes here
[H W] = size(L);
for hh = 1:H
    for w = 1:W
        if L(hh,w) < SS(hh,w),
           L(hh,w) = SS(hh,w);
        end
        if L(hh,w) >1,
            L(hh,w) = 1;
        end
    end
end
end
