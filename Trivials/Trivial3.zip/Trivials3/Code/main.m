% COLOR IMAGE ENHANCEMENT USING RETINEXWITH ROBUST RECURSIVE ENVELOPE
% Chih-Tsung Shen and Wen-Liang Hwang
% ICIP 2009
% Copy-Left

% S = L R
close all;
clear;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Read File
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
filename = 'kf.jpg';
f = imread(filename);
figure,imshow(f),title('input');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% H S V
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
hsv = rgb2hsv(f);h = hsv(:,:,1);s = hsv(:,:,2);v = hsv(:,:,3);
figure,imshow(v),title('v');
[H W] = size(v);
SS=v;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Setting
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
Klap = [0  1 0;
        1 -4 1;
        0 1 0];
IT = 100; %
alpha = 0.0001;%0.0001
beta = 0.1;
mju = 0.2;%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% delta S
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%hs = fspecial('PYM');
hs = [1 1 1 0 -1 -1 -1;
      1 2 2 0 -2 -2 -1;
      1 2 3 0 -3 -2 -1;
      1 2 3 0 -3 -2 -1;
      1 2 3 0 -3 -2 -1;  
      1 2 2 0 -2 -2 -1;
      1 1 1 0 -1 -1 -1];
hs = hs/34;
% hs = [ -2  1 -2;
%         1 -4  1;
%        -2  1 -2];   
PYM_h = imfilter(v,hs,'symmetric');
PYM_v = imfilter(v,hs','symmetric');
PYM_SS = abs(PYM_h) + abs(PYM_v); % for Huber
figure,imshow(PYM_SS),title('PYM__SS');
%imwrite(PYM_SS,'PYM_SS.bmp','bmp');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Main Idea
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
L = SS;
%Th = -1/7;
Th = 0.2;
w0 = 0.9;
for it = 1:IT
    L_last = L;
    GA = imfilter(L,Klap,'symmetric');
    G = -GA + alpha*( L - SS );
    L = L - mju*G;
    %L = Envelope(L,SS);%
    %
    for hh = 1:H
        for w = 1:W
            if (PYM_SS(hh,w)) >= Th,
                wtune = w0;
                L(hh,w) = wtune*SS(hh,w) + (1-wtune)*L(hh,w);                
            else
                wtune = w0*(PYM_SS(hh,w)/Th)*(PYM_SS(hh,w)/Th);
                L(hh,w) = wtune*SS(hh,w) + (1-wtune)*L(hh,w);   
            end
        end
    end     
    L = Envelope(L,SS);%Move forward
    CostIT(it) = CostFunc2(L,SS,alpha);
end
figure,imshow(L),title('L');
%imwrite(L,'L.bmp','bmp');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% envelop check!
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
check_M = int16(100) %
S_envelop = SS(check_M,:);
L_envelop = L(check_M,:);

figure,plot(S_envelop); 
hold on;plot(L_envelop,'r');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% reflectance
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
R = SS./L;
figure,imshow(R),title('R');
%imwrite(R,'R.bmp','bmp');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% gamma
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
gamma = 2.5;% gamma = 3;
L(L>1) = 1;
L = (L).^(1/gamma);
figure,imshow(L),title('L');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% enhance
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
SS = L.*R;
figure,imshow(SS),title('SS');
hsv = cat(3,h,s,SS);
output = hsv2rgb(hsv);
figure,imshow(output),title('output');
%imwrite(output,'output.bmp','bmp');