% example: guided feathering
% figure 9 in our paper

close all;
vargin1='toy.bmp';
I = double(image_load(vargin1)) / 255;
vargin2='toy-mask.bmp';
p = double(rgb2gray(image_load(vargin2))) / 255;

r = 60;
eps = 10^-6;

q = guidedfilter_color(I, p, r, eps);

figure();
imshow([I, repmat(p, [1, 1, 3]), repmat(q, [1, 1, 3])], [0, 1]);
