function [R,G,B]=Lab2RGB(L,a,b)
%Lab to XYZ
if nargin==1
    b=L(:,:,3);
    a=L(:,:,2);
    L=L(:,:,1);
end
[m,n]=size(L);
L=reshape(L,1,m*n);
a=reshape(a,1,m*n);
b=reshape(b,1,m*n);
%Set Threshold
Th=6/29;
%compute Y
fY=((L+16)/116).^3;
YT=fY>Th;
%1/3*(29/6)^2=7.787
fY=(~YT).*(L/(116*7.787))+YT.*fY;
Y=fY;
%compute X
fX=a/500+fY;
XT=fX>Th;
X=(XT.*(fX.^3)+(~XT).*((fX-16/116)/7.787));
%compute Z
fZ=fY-b/200;
ZT=fZ>Th;
Z=(ZT.*(fZ.^3)+(~ZT).*((fZ-16/116)/7.787));

%XYZ to RGB
%{
XYZ to RGB transformation 1
3.240479   -1.537150  -0.498535
-0.969256  1.875992   0.041556
0.055648   -0.204043  1.057311
XYZ to RGB transformation 2(normalized)
3.0799327  -1.537150  -0.542782
-0.921235  1.875992   0.0452442
0.0528909  -0.204043  1.1511515
%}
XYZ=[X;Y;Z];
%Using the normalized  transformation matrix and discard the normalizing process
Trans=[3.240479 -1.537150 -0.498535;
       -0.969256 1.875992 0.041556;
       0.055648 -0.204043 1.057311;];
XYZ(1,:)=XYZ(1,:)*0.950456;
XYZ(3,:)=XYZ(3,:)*1.088754;
RGB=max(min(Trans*XYZ,1),0);%mapping the values of RGB channels to interval [0,1]
R=reshape(RGB(1,:),m,n);
G=reshape(RGB(2,:),m,n);
B=reshape(RGB(3,:),m,n);
if nargout==1
  R=uint8(round(cat(3,R,G,B)*255));
end