function [Y,U,V] = RGB2YUV(Im)
R=Im(:,:,1);
G=Im(:,:,2);
B=Im(:,:,3);
Y=0.299*R+0.587*G+0.114*B;
U=0.492*(B-Y);
V=0.877*(R-Y);