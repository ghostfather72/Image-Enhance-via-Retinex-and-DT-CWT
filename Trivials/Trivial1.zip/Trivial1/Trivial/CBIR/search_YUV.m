function YUV_result = search_YUV(file_name1,file_name2)
[Yq_1,Uq_1,Vq_1] = load_image(file_name1);
[Yq_2,Uq_2,Vq_2] = load_image(file_name2);

w_y = 0.8;
w_u = 0.1;
w_v = 0.1;

Dy_matric = abs(Yq_1 - Yq_2);
Du_matric = abs(Uq_1 - Uq_2);
Dv_matric = abs(Vq_1 - Vq_2);
dy_qi2 = sum(Dy_matric(:));
du_qi2 = sum(Du_matric(:));
dv_qi2 = sum(Dv_matric(:));
distant_YUV = w_y * dy_qi2 + w_u * du_qi2 + w_v * dv_qi2;

YUV_result = distant_YUV/ 393216;
