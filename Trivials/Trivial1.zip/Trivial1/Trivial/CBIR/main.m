file_name1 = 'image1.jpg';
file_name2 = 'image2.jpg';
GIST_result = search_GIST(file_name1,file_name2);
HSV_result = search_HSV(file_name1,file_name2);
YUV_result = search_YUV(file_name1,file_name2);

fid = fopen('score.txt', 'wt');
HSV_propotion = 0.2;
YUV_propotion = 0.4;
GIST_propotion = 0.4; 

result = 1 - HSV_propotion*HSV_result - YUV_propotion*YUV_result - GIST_propotion*GIST_result

fprintf(fid,'%f',result);
fclose(fid);



