function GIST_result= search_GIST(file_name1,file_name2)
param.imageSize = 128;
param.orientationsPerScale = [8 8 8 8];
param.numberBlocks = 4;
param.fc_prefilt = 4;

GIST_file_name1 = imread(file_name1);
GIST_file_name2 = imread(file_name2);
[gist_file_name1, param1] = LMgist(GIST_file_name1, '', param)
[gist_file_name2, param2] = LMgist(GIST_file_name2, '', param)

feature_dimention = 512;
distant = 0;

for j = 1:feature_dimention
	distant = distant + abs(gist_file_name1(j)-gist_file_name2(j));
end

GIST_result = distant/60;




