function [Yq_ll,Uq_ll,Vq_ll] = load_image(file_name)
query_image = imread(file_name);
[Yq,Uq,Vq] = RGB_to_YUV(query_image);
[imageh,imagew,k] = size(query_image);
if imageh > imagew
    Yq = Yq';
    Uq = Uq';
    Vq = Vq';
end
Yq_ll = DWT2_3layers(Yq);
Uq_ll = DWT2_3layers(Uq);
Vq_ll = DWT2_3layers(Vq);

