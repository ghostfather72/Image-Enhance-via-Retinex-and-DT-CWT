function [Y,U,V] = RGB_to_YUV(translation_image)
R=translation_image(:,:,1);
G=translation_image(:,:,2);
B=translation_image(:,:,3);
Y=0.299*R+0.587*G+0.114*B;
U=0.492*(B-Y);
V=0.877*(R-Y);