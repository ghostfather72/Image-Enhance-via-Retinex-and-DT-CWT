function HSV_result= search_HSV(file_name1,file_name2)
HSV_file_name1 = HSV_feature(file_name1) ;
HSV_file_name2 = HSV_feature(file_name2) ;
distant_HSV = 0;
feature_dimention = 1152;
for j = 1:feature_dimention
	distant_HSV = distant_HSV + abs(HSV_file_name1(j)-HSV_file_name2(j));
end
HSV_result = distant_HSV/195840;
