function HSV_bin = HSV_feature(imagedir)
temp = imagedir;
temp = imread(temp);

HSV=rgb2hsv(temp); 
H=HSV(:,:,1);
S=HSV(:,:,2);
V=HSV(:,:,3);
[height,width] = size(H);

H_bin_num = 8;
S_bin_num = 4;
V_bin_num = 4;

H_bin_width = 1/H_bin_num;
S_bin_width = 1/S_bin_num;
V_bin_width = 1/V_bin_num;

blocknumh = 3;
blocknumw = 3;
blockh = floor(height/blocknumh);
blockw = floor(width/blocknumw);
HSV_bin_temp = zeros(H_bin_num ,S_bin_num ,V_bin_num,blocknumh*blocknumw);


for i= 1:blocknumh
    for j= 1:blocknumw
        xbegin = 1 + blockw*(j-1);
        xend = blockw*j;
        ybegin = 1 + blockh*(i-1);
        yend = blockh*i;
        for x = xbegin:xend
            for y = ybegin:yend
        if ceil(H(y,x)/H_bin_width) == 0
            index1 = 1;
        else
            index1 = ceil(H(y,x)/H_bin_width);
        end
        if ceil(S(y,x)/S_bin_width) == 0
            index2 = 1;
        else
            index2 = ceil(S(y,x)/S_bin_width);
        end
        if ceil(V(y,x)/V_bin_width) == 0
            index3 = 1;
        else
            index3 = ceil(V(y,x)/V_bin_width);
        end
        HSV_bin_temp(index1,index2,index3,(i-1)*blocknumw + j) = HSV_bin_temp(index1,index2,index3,(i-1)*blocknumw + j)+1;
            end
        end
    end
end


bins = H_bin_num*S_bin_num*V_bin_num;
HSV_bin = zeros(1,bins*blocknumh*blocknumw);

for index = 1:blocknumh*blocknumw
%     if index == 6 || index == 7 || index == 8 || index == 9
%         amplify = 1.5;
%     elseif index == max_index && index ~= 6 && index ~= 7 &&index ~= 8 &&index ~= 9 
%         amplify =1.25;
%     else
        amplify = 1;
%     end
for i1 = 1:H_bin_num
    for i2 = 1:S_bin_num
        for i3 = 1:V_bin_num
            HSV_bin_index = (i1-1)*S_bin_num*V_bin_num + (i2-1)*V_bin_num + i3 + (index-1) * bins;
            HSV_bin(HSV_bin_index) = HSV_bin_temp(i1,i2,i3,index)*amplify;
        end
    end
end
end

% clear HSV_bin_temp;