function Xll = DWT2_3layers(X)
nbcol = size(X,1);
% Perform one step decomposition.
        [ca1,ch1,cv1,cd1] = dwt2(X,'db1');
 
 % Image coding.
        cod_ca1 = wcodemat(ca1,nbcol);
        cod_ch1 = wcodemat(ch1,nbcol);
        cod_cv1 = wcodemat(cv1,nbcol);
        cod_cd1 = wcodemat(cd1,nbcol);
%         image([cod_ca1,cod_ch1;cod_cv1,cod_cd1]);
        
        % decompose approx. cfs of level 1.
        [ca2,ch2,cv2,cd2] = dwt2(ca1,'db1');
 
 % Code ca2, ch2,cv2 and cd2.
        cod_ca2 = wcodemat(ca2,nbcol);
        cod_ch2 = wcodemat(ch2,nbcol);
        cod_cv2 = wcodemat(cv2,nbcol);
        cod_cd2 = wcodemat(cd2,nbcol);
        %          image([[cod_ca2,cod_ch2;cod_cv2,cod_cd2],cod_ch1;cod_cv1,cod_cd1]);
    % decompose approx. cfs of level 2.     
        [ca3,ch3,cv3,cd3] = dwt2(ca2,'db1');   
                cod_ca3 = wcodemat(ca3,nbcol);
                cod_ch3 = wcodemat(ch3,nbcol);
                cod_cv3 = wcodemat(cv3,nbcol);
                cod_cd3 = wcodemat(cd3,nbcol); 
Xll=cod_ca3;