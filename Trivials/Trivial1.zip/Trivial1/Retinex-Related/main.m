% main.m
clc;
clear;
close all;

%data = imread('original.png');
data = imread('whitehouse.png');

% ��û�кܺ���ǿ�ĵط�
pointAll = [195,350];
windSize = [120,120];
[state,data]=draw_rect(data,pointAll,windSize,1);
patch = data(197:197+116,352:352+116,:);
%figure,
%imshow(imresize(patch,1,'bicubic'))
% ������ϸ�ڲ���
%pointAll = [85,627];
%windSize = [120,145];
%[state,data]=draw_rect(data,pointAll,windSize,0);
%patch = data(87:87+141,628:628+117,:);
%figure,
%imshow(imresize(patch,1.5,'bicubic'))
% ����ʧ����
%pointAll = [350,510];
%windSize = [120,120];
%[state,results]=draw_rect(data,pointAll,windSize,0);
%patch = data(350:350+120,510:510+120,:);
%figure,
%imshow(imresize(patch,1.5,'bicubic'))