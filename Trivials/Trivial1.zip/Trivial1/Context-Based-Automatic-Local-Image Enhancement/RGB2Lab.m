function [L,a,b]=RGB2Lab(R,G,B)
%%RGB to XYZ
if nargin==1
    B=double(R(:,:,3));
    G=double(R(:,:,2));
    R=double(R(:,:,1));
end
if max(max(R))>1.0||max(max(G))>1.0||max(max(B))>1.0
    R = double(R)/255;
    G = double(G)/255;
    B = double(B)/255;
end
[m,n]=size(R);
RGB=[reshape(R,1,m*n);reshape(G,1,m*n);reshape(B,1,m*n)];
%Using the normalized  transformation matrix and discard the normalizing process
Trans=[0.412453    0.357580    0.180423;
       0.212671    0.715160    0.072169;
       0.019334    0.119193    0.950227;];
XYZ=Trans*RGB;
%Normalizing process
X=XYZ(1,:)/0.950456;
Y=XYZ(2,:);
Z=XYZ(3,:)/1.088754;

%%XYZ to Lab
%Set Threshold
Th=(6/29)^3;
%Find the values of XYZ channels which is larger than the threshold
XT=X>Th;
YT=Y>Th;
ZT=Z>Th;
%Compute f(Y/Yn),f(X/Xn),f(Z/Zn),where Yn,Xn,Zn=1
fX=XT.*X.^(1/3)+(~XT).*((1/3*(29/6)^2).*X+4/29);
fY=YT.*Y.^(1/3)+(~YT).*((1/3*(29/6)^2).*Y+4/29);
fZ=ZT.*Z.^(1/3)+(~ZT).*((1/3*(29/6)^2).*Z+4/29);
%Get the Lab space
L=reshape(round(116*fY-16),m,n);
a=reshape(round(500*(fX-fY)),m,n);
b=reshape(round(200*(fY-fZ)),m,n);
if nargout==1
  L=cat(3,L,a,b);
end