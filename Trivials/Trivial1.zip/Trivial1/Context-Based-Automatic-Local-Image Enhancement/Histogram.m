function histogram=Histogram(Lab)
b=Lab(:,:,3);
a=Lab(:,:,2);
L=Lab(:,:,1);
[m,n]=size(L);
%geting the histogram of each channel
bins=[4,8,8];
[HL,XL]=hist(reshape(L,1,m*n),bins(1));
[HA,XA]=hist(reshape(a,1,m*n),bins(2));
[HB,XB]=hist(reshape(b,1,m*n),bins(3));
%mapping the Lab images to the 256-dimensional feature vector
histogram=zeros(256,1);
for i=1:m
    for j=1:n
        [ll,indexl]=sort(abs(XL-L(i,j)));
        [aa,indexa]=sort(abs(XA-a(i,j)));
        [bb,indexb]=sort(abs(XB-b(i,j)));
        index=(indexl(1)-1)*bins(2)*bins(3)+(indexa(1)-1)*bins(3)+indexb(1);
        histogram(index)=histogram(index)+1;
    end
end
%Normalized
