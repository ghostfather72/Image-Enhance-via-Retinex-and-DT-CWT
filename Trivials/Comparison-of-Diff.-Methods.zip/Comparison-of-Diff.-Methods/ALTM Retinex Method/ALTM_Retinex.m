function outval = ALTM_Retinex(I)

Ir = double(I(:,:,1));
Ig = double(I(:,:,2));
Ib = double(I(:,:,3));

% Global Adaptation
Lw = 0.299 * Ir + 0.587 * Ig + 0.114 * Ib;% input world luminance values
Lwmax = max(max(Lw));% the maximum luminance value
[m, n] = size(Lw);
Lwaver = exp(sum(sum(log(0.001 + Lw))) / (m * n));% log-average luminance
Lg = log(Lw / Lwaver + 1) / log(Lwmax / Lwaver + 1);

% Local Adaptation
r = 10;
eps = 0.01;
eta = 36;
lambda = 10;

% O(1)���Ӷȵ���Сֵ�˲�
kenlRatio = 0.01;
krnlsz = floor(max([3, m * kenlRatio, n * kenlRatio]));
Lg1 = maxfilt2(Lg, [krnlsz, krnlsz]);
Lg1(m, n) = 0;

Hg = guidedfilter(Lg, Lg1, r, eps);
Hg(find(Hg <= 0)) = 1 / 255;

alpha = 1 + eta * Lg / max(max(Lg));
Lgaver = exp(sum(sum(log(1 / 255 + Lg))) / (m * n));
beta = lambda * Lgaver;

Lout = alpha .* log(Lg ./Hg + beta);
Min = min(min(Lout));
Max = max(max(Lout));
Lout = (Lout - Min) * 255 / (Max - Min);
n_b = find(Lout > 255);
Lout(n_b) = 255;
m_b = find(Lout < 0);
Lout(m_b) = 0;

gain = Lout ./ Lw;
[m, n] = size(gain);
for i = 1 : m
    for j = 1 : n
        if Lw(i, j) == 0
            gain(i, j) = Lout(i, j);
        end
    end
end
Irout = gain .* Ir;
Irout = Irout / max(max(Irout)) * 255;
Igout = gain .* Ig;
Igout = Igout / max(max(Igout)) * 255;
Ibout = gain .* Ib;
Ibout = Ibout / max(max(Ibout)) * 255;
outval = cat(3, Irout, Igout, Ibout);