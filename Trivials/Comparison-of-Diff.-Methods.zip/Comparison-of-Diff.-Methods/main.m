clc,clear
%*****************************Add Folders' Path****************************
addpath(genpath('Dark Channel Prior'));
addpath(genpath('ALTM Retinex Method'));
addpath(genpath('Image Evaluation'));
addpath(genpath('Plot Image'));
addpath(genpath('MSRCP Method'));
addpath(genpath('BPDFHE Method'));
addpath(genpath('PyrTools'));
addpath(genpath('LTM-SDMSR Method'));
addpath(genpath('Novel Retinex Method'));

%********************************Image Load********************************
img = imread('Original3.png');
ref = imread('Reference3.png');

%eva = image_evaluate(double(img), ref);

%************************************SSR***********************************
ssr = SSR(img);
%eva_ssr = image_evaluate(ssr, ref);
%figure,imshow(ssr / 255)
figure,imhist(ssr(:,:,1) / 255)
hold on
imhist(ssr(:,:,2) / 255)
imhist(ssr(:,:,3) / 255)
hold off

%************************************MSR***********************************
msr = MSR(img);
%eva_msr = image_evaluate(msr, ref);
%figure,imshow(msr / 255)
figure,imhist(msr(:,:,1) / 255)
hold on
imhist(msr(:,:,2) / 255)
imhist(msr(:,:,3) / 255)
hold off

%***********************************MSRCR**********************************
msrcr = MSRCR(img);
%eva_msrcr = image_evaluate(msrcr, ref);
%figure,imshow(msrcr / 255)
figure,imhist(msrcr(:,:,1) / 255)
hold on
imhist(msrcr(:,:,2) / 255)
imhist(msrcr(:,:,3) / 255)
hold off

%***********************************MSRCP**********************************
msrcp = MSRCP(img);
%eva_msrcp = image_evaluate(msrcp, ref);
%figure,imshow(msrcp / 255)
figure,imhist(msrcp(:,:,1) / 255)
hold on
imhist(msrcp(:,:,2) / 255)
imhist(msrcp(:,:,3) / 255)
hold off

%*******************************Frankle Mccann*****************************
%r = double(img(:, :, 1)); g = double(img(:, :, 2)); b = double(img(:, :, 3));
%R = retinex_frankle_mccann(r / 255, 4);
%G = retinex_frankle_mccann(g / 255, 4);
%B = retinex_frankle_mccann(b / 255, 4);
%rgb = cat(3, R, G, B);
%eva_frankle = image_evaluate(rgb * 255, ref);

%**********************************Mccann99********************************
%r = double(img(:, :, 1)); g = double(img(:, :, 2)); b = double(img(:, :, 3));
%R = retinex_mccann99(r / 255, 4);
%G = retinex_mccann99(g / 255, 4);
%B = retinex_mccann99(b / 255, 4);
%rgb = cat(3, R, G, B);
%eva_mccann = image_evaluate(rgb * 255, ref);

%*********************************LTM SDMSR********************************
ltmsdmsr = LTMSDMSR(img);
%eva_ltmsdmsr = image_evaluate(ltmsdmsr, ref);
%figure,imshow(ltmsdmsr / 255)
figure,imhist(ltmsdmsr(:,:,1) / 255)
hold on
imhist(ltmsdmsr(:,:,2) / 255)
imhist(ltmsdmsr(:,:,3) / 255)
hold off

%********************************ALTM Retinex******************************
altmr = ALTM_Retinex(img);
%eva_altmr = image_evaluate(altmr, ref);
%figure,imshow(altmr / 255)
figure,imhist(altmr(:,:,1) / 255)
hold on
imhist(altmr(:,:,2) / 255)
imhist(altmr(:,:,3) / 255)
hold off

%***********************************BPDFHE*********************************
lab = rgb2lab(img);
L = lab(:, :, 1); a = lab(:, :, 2); b = lab(:, :, 3);
L = fcnBPDFHE(L);
bpdfhe = lab2rgb(cat(3, L, a, b));
bpdfhe(find(bpdfhe > 1)) = 1;
bpdfhe(find(bpdfhe < 0)) = 0;
%eva_bpdfhe = image_evaluate(bpdfhe * 255, ref);
%figure,imshow(bpdfhe)
figure,imhist(bpdfhe(:,:,1))
hold on
imhist(bpdfhe(:,:,2))
imhist(bpdfhe(:,:,3))
hold off

%********************************Novel Retinex*****************************
novelretinex = Novel_Retinex(img);
%eva_novelretinex = image_evaluate(novelretinex, ref);
%figure,imshow(novelretinex / 255)
figure,imhist(novelretinex(:,:,1) / 255)
hold on
imhist(novelretinex(:,:,2) / 255)
imhist(novelretinex(:,:,3) / 255)
hold off

%outval = [eva; eva_ssr; eva_msr; eva_msrcr; eva_msrcp; eva_ltmsdmsr;...
%    eva_altmr; eva_bpdfhe; eva_novelretinex;];

%****************************Remove Folders' Path**************************
rmpath 'Dark Channel Prior'
rmpath 'ALTM Retinex Method'
rmpath 'Image Evaluation'
rmpath 'Plot Image'
rmpath 'PyrTools'
rmpath 'MSRCP Method'
rmpath 'LTM-SDMSR Method'
rmpath 'BPDFHE Method'
rmpath 'Novel Retinex Method'