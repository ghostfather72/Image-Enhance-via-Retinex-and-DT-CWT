function outval = MSR(I)
if ndims(I) == 3
    Ir_double=double(I(:,:,1));
    Ig_double=double(I(:,:,2));
    Ib_double=double(I(:,:,3));
else
    Ir_double=double(I);
    Ig_double=double(I);
    Ib_double=double(I);
end
[m,n]=size(Ir_double);
if m<n
    h=m;
else
    h=n;
end
sigma1=double(uint8(h*0.23));%С�ߴ�Ϊͼ���С��3%
sigma2=double(uint8(h*0.43));%�гߴ�Ϊͼ���С��13%
sigma3=double(uint8(h*0.60));%��ߴ�Ϊͼ���С��40%
F1=fspecial('gaussian',[sigma1,sigma1],sigma1);
F2=fspecial('gaussian',[sigma2,sigma2],sigma2);
F3=fspecial('gaussian',[sigma3,sigma3],sigma3);
%*************R channel**************
L1=imfilter(Ir_double,F1,'replicate','conv');
%figure,imshow(L1/255)
L2=imfilter(Ir_double,F2,'replicate','conv');
L3=imfilter(Ir_double,F3,'replicate','conv');
G=double(1/3)*(log(Ir_double+1)-log(L1+1))+...
    double(1/3)*(log(Ir_double+1)-log(L2+1))+...
    double(1/3)*(log(Ir_double+1)-log(L3+1));
Min=min(min(G));
Max=max(max(G));
Rr=(G-Min)*255/(Max-Min);
n_r=find(Rr>255);
Rr(n_r)=255;
m_r=find(Rr<0);
Rr(m_r)=0;
%*************G channel**************
L1=imfilter(Ig_double,F1,'replicate','conv');
L2=imfilter(Ig_double,F2,'replicate','conv');
L3=imfilter(Ig_double,F3,'replicate','conv');
G=double(1/3)*(log(Ig_double+1)-log(L1+1))+...
    double(1/3)*(log(Ig_double+1)-log(L2+1))+...
    double(1/3)*(log(Ig_double+1)-log(L3+1));
Min=min(min(G));
Max=max(max(G));
Rg=(G-Min)*255/(Max-Min);
n_g=find(Rg>255);
Rg(n_g)=255;
m_g=find(Rg<0);
Rg(m_g)=0;
%*************B channel**************
L1=imfilter(Ib_double,F1,'replicate','conv');
L2=imfilter(Ib_double,F2,'replicate','conv');
L3=imfilter(Ib_double,F3,'replicate','conv');
G=double(1/3)*(log(Ib_double+1)-log(L1+1))+...
    double(1/3)*(log(Ib_double+1)-log(L2+1))+...
    double(1/3)*(log(Ib_double+1)-log(L3+1));
Min=min(min(G));
Max=max(max(G));
Rb=(G-Min)*255/(Max-Min);
n_b=find(Rb>255);
Rb(n_b)=255;
m_b=find(Rb<0);
Rb(m_b)=0;

outval=cat(3,Rr,Rg,Rb);