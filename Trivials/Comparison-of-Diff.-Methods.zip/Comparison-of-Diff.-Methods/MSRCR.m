function outval = MSRCR(I)
if ndims(I) == 3
    Ir = double(I(:, :, 1));
    Ig = double(I(:, :, 2));
    Ib = double(I(:, :, 3));
else
    Ir = double(I);
    Ig = double(I);
    Ib = double(I);
end
alpha = 125;
beta = 46;
gain = 30;
offset = -6;
cut = 2.45;
[m, n] = size(Ir);
if m < n
    h = m;
else
    h = n;
end
sigma1 = double(uint8(h * 0.23));%С�ߴ�Ϊͼ���С��3%
sigma2 = double(uint8(h * 0.43));%�гߴ�Ϊͼ���С��13%
sigma3 = double(uint8(h * 0.60));%��ߴ�Ϊͼ���С��40%
F1 = fspecial('gaussian', [sigma1, sigma1], sigma1);
F2 = fspecial('gaussian', [sigma2, sigma2], sigma2);
F3 = fspecial('gaussian', [sigma3, sigma3], sigma3);
%*************R channel**************
L1 = imfilter(Ir, F1, 'replicate', 'conv');
L2 = imfilter(Ir, F2, 'replicate', 'conv');
L3 = imfilter(Ir, F3, 'replicate', 'conv');
G = double(1/3)*(log(Ir+1)-log(L1+1))+...
    double(1/3)*(log(Ir+1)-log(L2+1))+...
    double(1/3)*(log(Ir+1)-log(L3+1));
C=beta*(log((Ir+1)*alpha)-log(Ir+Ig+Ib+3));
G=gain*(C.*G+offset);
u=mean2(G);%����ͼ��ľ�ֵ
s=std2(G);%����
Min=u-cut*s;%��Сֵ
Max=u+cut*s;%���ֵ
Rr=(G-Min)*255/(Max-Min);
Rr(find(Rr>255))=255;
Rr(find(Rr<0))=0;
%*************G channel**************
L1=imfilter(Ig,F1,'replicate','conv');
L2=imfilter(Ig,F2,'replicate','conv');
L3=imfilter(Ig,F3,'replicate','conv');
G=double(1/3)*(log(Ig+1)-log(L1+1))+...
    double(1/3)*(log(Ig+1)-log(L2+1))+...
    double(1/3)*(log(Ig+1)-log(L3+1));
C=beta*(log((Ig+1)*alpha)-log(Ir+Ig+Ib+3));
G=gain*(C.*G+offset);
u=mean2(G);%����ͼ��ľ�ֵ
s=std2(G);%����
Min=u-cut*s;%��Сֵ
Max=u+cut*s;%���ֵ
Rg=(G-Min)*255/(Max-Min);
Rg(find(Rg>255))=255;
Rg(find(Rg<0))=0;
%*************B channel**************
L1=imfilter(Ib,F1,'replicate','conv');
L2=imfilter(Ib,F2,'replicate','conv');
L3=imfilter(Ib,F3,'replicate','conv');
G=double(1/3)*(log(Ib+1)-log(L1+1))+...
    double(1/3)*(log(Ib+1)-log(L2+1))+...
    double(1/3)*(log(Ib+1)-log(L3+1));
C=beta*(log((Ib+1)*alpha)-log(Ir+Ig+Ib+3));
G=gain*(C.*G+offset);
u=mean2(G);%����ͼ��ľ�ֵ
s=std2(G);%����
Min=u-cut*s;%��Сֵ
Max=u+cut*s;%���ֵ
Rb=(G-Min)*255/(Max-Min);
Rb(find(Rb>255))=255;
Rb(find(Rb<0))=0;

outval=cat(3,Rr,Rg,Rb);