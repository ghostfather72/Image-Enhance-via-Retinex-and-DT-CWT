function outval = DarkChannelPrior(img)
kenlRatio = 0.01;
minAtomsLight = 240;
sz=size(img);
w=sz(2);
h=sz(1);
dc = zeros(h,w);
%derive the dark channel from original image
for y=1:h
    for x=1:w
        dc(y,x) = min(img(y,x,:));
    end
end

%minimum filter
krnlsz = floor(max([3, w*kenlRatio, h*kenlRatio]));
dc2 = minfilt2(dc, [krnlsz,krnlsz]);
dc2(h,w)=0;

t = 255 - dc2;

t_d=double(t)/255;
A = min([minAtomsLight, max(max(dc2))]);
J = zeros(h,w,3);
img_d = double(img);
J(:,:,1) = (img_d(:,:,1) - (1-t_d)*A)./t_d;
J(:,:,2) = (img_d(:,:,2) - (1-t_d)*A)./t_d;
J(:,:,3) = (img_d(:,:,3) - (1-t_d)*A)./t_d;

r = krnlsz*4;
eps = 10^-6;
filtered = guidedfilter(double(rgb2gray(img))/255, t_d, r, eps);
t_d = filtered;

J(:,:,1) = (img_d(:,:,1) - (1-t_d)*A)./t_d;
J(:,:,2) = (img_d(:,:,2) - (1-t_d)*A)./t_d;
J(:,:,3) = (img_d(:,:,3) - (1-t_d)*A)./t_d;
img_d(1,3,1);
outval = J;