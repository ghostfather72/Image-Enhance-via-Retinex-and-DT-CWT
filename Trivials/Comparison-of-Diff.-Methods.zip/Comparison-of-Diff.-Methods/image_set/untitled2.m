vargin='msrcp-memorial.png';
I=imread(vargin);
vargin='memorial-reference.jpg';
ref=imread(vargin);
[m,n,p]=size(ref);
I1=I(:,:,1);
I2=I(:,:,2);
I3=I(:,:,3);
I1 = imresize(I1,[m,n]);
I2 = imresize(I2,[m,n]);
I3 = imresize(I3,[m,n]);
I=cat(3,I1,I2,I3);

figure,imshow(I)
outval=image_evaluate(I,I)
figure,imhist(double(I(:,:,1))/255)
hold on
imhist(double(I(:,:,2))/255)
imhist(double(I(:,:,3))/255)
hold off
PSNR = psnr(I, ref)
[SSIMVAL, ~] = ssim(I, ref)
[FSIM, ~] = FeatureSIM(ref, I)
rgb1 = rgb2gray(I);
ref1 = rgb2gray(ref);
%vif = vifvec(ref1,rgb1)