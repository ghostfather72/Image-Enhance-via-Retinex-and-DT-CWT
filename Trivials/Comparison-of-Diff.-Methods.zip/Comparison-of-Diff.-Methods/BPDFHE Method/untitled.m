vargin='whitehouse.png';
I=image_load(vargin);

lab = rgb2lab(I);
L = lab(:, :, 1); a = lab(:, :, 2); b = lab(:, :, 3);
L = fcnBPDFHE(L);
rgb = lab2rgb(cat(3, L, a, b));
rgb(find(rgb > 1)) = 1;
rgb(find(rgb < 0)) = 0;

imwrite(uint8(rgb*255),'bpdfhe.png');