% This is the implementation of the paper:
% <A Novel Retinex Based Approach for Image Enhancement... 
% with Illumination Adjustment>
function outval = Novel_Retinex(I)
% Setting fixed Parameters
alpha = 10;
beta = 0.15;
gamma = 0.001;
a = 0.04;
sigma = 80;
maxIter = 4;

% Computing L0 using Gaussian low-pass filter
Int = double(rgb2gray(I));

F = fspecial('gaussian', [3 * sigma, 3 * sigma], sigma);
L0 = imfilter(Int, F, 'replicate', 'conv');

% RGB to HSV
[Sh, Ss, Sv] = rgb2hsv(I);% all the three channels are ranging from 0 to 1
% Mapping the values of Sv to [0,255]
Sv = Sv * 255;

% Initialization L
F = fspecial('gaussian',[3 * sigma,3 * sigma], sigma);
L = imfilter(Sv, F, 'replicate', 'conv');

% Initialization R
R = Sv ./ L;

% Set Sobel operators
hx = [-1, 0, 1; -2, 0, 2; -1, 0, 1];% horizontal direction Sobel operator
hy = [1, 2, 1; 0, 0, 0; -1, -2, -1];% vertical direction Sobel operator

% Iteration, we set 4 iterations. Plus, iter can set the value from 4 to 8
for iter = 1 : maxIter
    % Computing the difference operator in horizontal and vertical direction
    DxR = abs(imfilter(R, hx, 'replicate', 'conv'));
    DyR = abs(imfilter(R, hy, 'replicate', 'conv'));
    [m, n] = size(L);
    for i = 1 : m
        for j = 1 : n
            mole = fft(Sv(i, j) / L(i, j));
            deno = fft(1) + beta * (conj(fft(DxR(i, j))) * ...
                fft(DxR(i, j)) + conj(fft(DyR(i, j))) * fft(DyR(i, j)));
            R(i, j) = ifft(mole / deno);
            R(i, j) = min(1, max(R(i, j), 0));
        end
    end
    % Computing the difference operator in horizontal and vertical direction
    DxL = abs(imfilter(L, hx, 'replicate', 'conv'));
    DyL = abs(imfilter(L, hy, 'replicate', 'conv'));
    [m, n] = size(R);
    for i = 1 : m
        for j = 1 : n
            mole = fft(gamma * L0(i, j) + Sv(i, j) / R(i, j));
            deno = fft(1 + gamma) + alpha * (conj(fft(DxL(i, j))) * ...
                fft(DxL(i, j)) + conj(fft(DyL(i, j))) * fft(DyL(i, j)));
            L(i, j) = ifft(mole / deno);
            L(i, j) = max(L(i, j), Sv(i, j));
        end
    end
end

% Adjustment process
L_adjusted = 2 * atan(a * L) / pi;% Sigmoid function
L_final = adapthisteq(L_adjusted);% CLAHE method

% Final process
Sv_final = R .* L_final;
Shsv_final = cat(3, Sh, Ss, Sv_final);
outval = hsv2rgb(Shsv_final) * 255;