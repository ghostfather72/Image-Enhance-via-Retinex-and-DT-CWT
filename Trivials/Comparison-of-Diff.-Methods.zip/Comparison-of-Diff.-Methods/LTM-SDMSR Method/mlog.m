function out=mlog(in)
thet=128;
w=25;
[m,n]=size(in);
out=zeros(m,n);
for i=1:m
    for j=1:n
        if in(i,j)<thet
            out(i,j)=thet*log(w+in(i,j)+1)/log(w+thet+1);
        else
            out(i,j)=255-(255-thet)*log(w-in(i,j)+256)/log(w-thet+256);
        end
    end
end