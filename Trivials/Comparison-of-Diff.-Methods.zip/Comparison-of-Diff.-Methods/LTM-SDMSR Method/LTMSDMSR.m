function ltmsdmsr = LTMSDMSR(I)
I=double(I);
Ir=I(:,:,1);
Ig=I(:,:,2);
Ib=I(:,:,3);

% A. Global Dynamic Range Compression
L=0.21*Ir+0.72*Ig+0.072*Ib;
Lmax=max(max(L));
Lmin=min(min(L));
Lg=(log(L+1)-log(Lmin+1))/(log(Lmax+1)-log(Lmin+1));

% B. Local contrast enhancement using SD-MSR, where Nb=3
[m,n]=size(Lg);
kenlRatio = 0.01;
krnlsz = floor(max([3, m * kenlRatio, n * kenlRatio]));
Lg2 = maxfilt2(Lg, [krnlsz, krnlsz]);
Lg2 = imresize(Lg2, [m,n]);

r=[10,20,40];
eps=[0.1^2,0.2^2,0.4^2];
H1=guidedfilter(Lg,Lg2,r(1),eps(1));
H2=guidedfilter(Lg,Lg2,r(2),eps(2));
H3=guidedfilter(Lg,Lg2,r(3),eps(3));

R1=mlog(Lg*255)-mlog(H1*255);
R2=mlog(Lg*255)-mlog(H2*255);
R3=mlog(Lg*255)-mlog(H3*255);

sdR1=R1;
sdR2=R2-R1;
sdR3=R3-R2;

Max=max(max(abs(sdR1)));
NR1=abs(sdR1)/Max;
Max=max(max(abs(sdR2)));
NR2=abs(sdR2)/Max;
Max=max(max(abs(sdR3)));
NR3=abs(sdR3)/Max;

r1=r(1)/max(r);
r2=r(2)/max(r);
r3=r(3)/max(r);
epsilon=0.1;
g1=(1./(NR1+epsilon)).^(1-r1);
g2=(1./(NR2+epsilon)).^(1-r2);
g3=(1./(NR3+epsilon)).^(1-r3);

R=g1.*sdR1+g2.*sdR2+g3.*sdR3;
R=normfun(R,255);

%color processing
Er=R.*(Ir./L);
Eg=R.*(Ig./L);
Eb=R.*(Ib./L);
ltmsdmsr=cat(3,Er,Eg,Eb);
ltmsdmsr(find(ltmsdmsr > 255)) = 255;
ltmsdmsr(find(ltmsdmsr < 0)) = 0;
ltmsdmsr(find(isnan(ltmsdmsr) == 1)) = 0;
ltmsdmsr(find(ltmsdmsr == Inf)) = 255;