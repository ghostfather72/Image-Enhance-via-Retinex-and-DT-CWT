% This is the implementation of the paper:
% <A Novel Retinex Based Approach for Image Enhancement... 
% with Illumination Adjustment>
% Input:
%    RGB color image, alpha=10, beta=0.1, gamma=0.001, a=0.02, L0
% Output:
%    Enhanced image, Illumination L, Reflectance R

% Getting the observed color image
vargin='whitehouse.png';
I=image_load(vargin);
% Setting fixed Parameters
alpha=10;
beta=0.15;
gamma=0.001;
a=0.04;% the paper is set as 5, but 0.1 is more better
sigma=80;

% Computing L0 using Gaussian low-pass filter
Int=double(rgb2gray(I));

F=fspecial('gaussian',[3*sigma,3*sigma],sigma);
L0=imfilter(Int,F,'replicate','conv');

% RGB to HSV
[Sh,Ss,Sv]=rgb2hsv(I);% all the three channels are ranging from 0 to 1
% Mapping the values of Sv to [0,255]
Sv=normfun(Sv,255);

% Initialization L
F=fspecial('gaussian',[3*sigma,3*sigma],sigma);
L=imfilter(Sv,F,'replicate','conv');
% Initialization R
R=Sv./L;
% Mapping the values of R to [0,1]
%R=normfun(R,1);

% Iteration, we set 4 iterations. Plus, iter can set the value from 4 to 8
for iter=1:4
    % Set Sobel operators
    hx=[-1,0,1;-2,0,2;-1,0,1];
    % Computing the difference operator in horizontal and vertical direction
    DxL=abs(imfilter(L,hx,'replicate','conv'));
    DyL=abs(imfilter(L,hx','replicate','conv'));
    DxR=abs(imfilter(R,hx,'replicate','conv'));
    DyR=abs(imfilter(R,hx','replicate','conv'));
    % Update R
    mole=fft2(Sv./L);
    deno=fft2(1)+beta*(conj(fft2(DxR)).*fft2(DxR)+...
        conj(fft2(DyR)).*fft2(DyR));
    R=ifft2(mole./deno);
    R=min(1,max(R,0));
    % Update L
    mole=fft2(gamma*L0+Sv./R);
    deno=fft2(1+gamma)+alpha*(conj(fft2(DxL)).*fft2(DxL)+...
                conj(fft2(DyL)).*fft2(DyL));
    L=ifft2(mole./deno);
    L=max(L,Sv);
end
imshow(L/255)
% Adjustment process
R=ones(size(L));
% Using sigmoid function to normalize L
L_adjusted=2*atan(a*L)/pi;

% Using CLAHE method to process L
L_final=adapthisteq(L_adjusted);

% Final process
%Sv_final=R.*L_final;
Sv_final=R.*L_final;
Shsv_final=cat(3,Sh,Ss,Sv_final);
Srgb=hsv2rgb(Shsv_final);
figure,imshow(Srgb)
%outval=evaluate(Srgb*255,double(I))
% Evaluating process
%[Mean,Std,Mse,PSNR,Entropy,Gradval,Edge_intensity,...
%    Contrast_ratio]=evaluate(Srgb*255,I);