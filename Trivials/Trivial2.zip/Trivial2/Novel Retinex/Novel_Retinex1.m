% This is the implementation of the paper:
% <A Novel Retinex Based Approach for Image Enhancement... 
% with Illumination Adjustment>
% Input:
%    RGB color image, alpha=10, beta=0.1, gamma=0.001, a=0.02, L0
% Output:
%    Enhanced image, Illumination L, Reflectance R

% Getting the observed color image
clc;clear;
%vargin='horses.png';
%vargin = 'sneaker.png';
%I=image_load(vargin);
I = imread('Original.png');
% Setting fixed Parameters
alpha=10;
beta=0.15;
gamma=0.001;
a=10;% the paper is set as 5, but 0.1 is more better
sigma=80;

% Computing L0 using Gaussian low-pass filter
Int=double(rgb2gray(I));

F=fspecial('gaussian',[3*sigma,3*sigma],sigma);
L0=imfilter(Int,F,'replicate','conv');

% RGB to HSV
[Sh,Ss,Sv]=rgb2hsv(I);% all the three channels are ranging from 0 to 1
% Mapping the values of Sv to [0,255]
%Sv=normfun(Sv,255);
%Sv = Sv * 255;
%figure,imshow(Sv)

%figure,imshow(Sv/255)
%[m,n]=size(Sv);
%figure,hist(reshape(Sv,1,m*n),255);

% Initialization L
F=fspecial('gaussian',[3*sigma,3*sigma],sigma);
L=imfilter(Sv,F,'replicate','conv');

% Initialization R
%R=Sv./L;
%figure,imshow(R)
% Mapping the values of R to [0,1]
%R=normfun(R,1);
%figure,imshow(R)
%figure,imshow(R),title('R before iteration')
% Set Sobel operators
hx=[-1,0,1;-2,0,2;-1,0,1];% horizontal direction Sobel operator
hy=[1,2,1;0,0,0;-1,-2,-1];% vertical direction Sobel operator

% Iteration, we set 4 iterations. Plus, iter can set the value from 4 to 8
for iter=1:4
    % Computing the difference operator in horizontal and vertical direction
    DxL=abs(imfilter(L,hx,'replicate','conv'));
    DyL=abs(imfilter(L,hy,'replicate','conv'));
    %[m,n]=size(L);
    %for i=1:m
     %   for j=1:n
            mole=fft2(Sv./L);
            deno=fft2(ones(size(L)))+alpha*(conj(fft2(DxL)).*fft2(DxL)+...
                conj(fft2(DyL)).*fft2(DyL));
            R=ifft2(mole./deno);
            R=min(1,max(R,0));
            %figure,imshow(R)
     %   end
    %end
    % Computing the difference operator in horizontal and vertical direction
    DxR=abs(imfilter(R,hx,'replicate','conv'));
    DyR=abs(imfilter(R,hy,'replicate','conv'));
    %[m,n]=size(R);
    %for i=1:m
     %   for j=1:n
            mole=fft2(gamma*L0+Sv./R);
            deno=fft2(ones(size(R))+gamma)+beta*(conj(fft2(DxR)).*fft2(DxR)+...
                conj(fft2(DyR)).*fft2(DyR));
            L=ifft2(mole./deno);
            L=max(L,Sv);
     %   end
    %end
end
%figure,imshow(L)
%sigma = 15;
%F = fspecial('gaussian', [sigma, sigma], sigma);
%R = imfilter(R, F, 'replicate', 'conv');
%figure,imshow(L/255)
%figure,imshow(R)
%figure,imshow(L/255),title('L after iteration')
%figure,imshow(R),title('R after iteration')
% Adjustment process
L_adjusted=2*atan(a*L)/pi;% Sigmoid function
%figure,imshow(L_adjusted),title('L filtered by Sigmoid Function')
%L_final=L_adjusted;
L_final=adapthisteq(L_adjusted);% CLAHE method
%figure,imshow(L_final)
%figure,imshow(L_final),title('L using CLAHE method')
%R=ones(size(L));
% Final process
Sv_final=R.*L_final;
%figure,imshow(Sv_final)
%[m,n]=size(Sv_final);
%figure,hist(reshape(Sv_final,1,m*n),255);
Shsv_final=cat(3,Sh,Ss,Sv_final);
rgb=hsv2rgb(Shsv_final);
%outval=easy_evaluate(Srgb_final*255,double(I))
figure,imshow(rgb),title('Novel Retinex using CLAHE')
%figure,imhist(rgb(:,:,1));
%figure,imhist(rgb(:,:,2));
%figure,imhist(rgb(:,:,3));
%figure,Histogram(double(Srgb_final)),title('Histogram of the result')