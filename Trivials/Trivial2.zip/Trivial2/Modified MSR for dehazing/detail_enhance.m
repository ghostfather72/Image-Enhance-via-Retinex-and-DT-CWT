function out=detail_enhance(I)
% Sobel operator
%l=fspecial('Sobel');% ˮƽ����
%G=abs(imfilter(Ir,l,'replicate','conv')+imfilter(Ir,l','replicate','conv'));
% Laplacian operator
% Mode 1:
%lap=[0 -1 0; -1 4 -1; 0 -1 0];
% Mode 2:
k=0.4;
lap=[-1 -1 -1; -1 8 -1; -1 -1 -1];
G=imfilter(I,lap,'replicate','conv');
out=I+k*normfun(abs(G),255);
m=find(out>255);
out(m)=255;
n=find(out<0);
out(n)=0;