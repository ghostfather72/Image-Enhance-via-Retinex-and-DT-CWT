function out=match_enhance(I)
t=3;
mu=mean2(I);
delta=std2(I);
Ibw=mu-t*delta;
Ihigh=mu+t*delta;
[m,n]=size(I);
for i=1:m
    for j=1:n
        if I(i,j)<Ibw
            I(i,j)=0;
        elseif I(i,j)>Ihigh;
            I(i,j)=255;
        else
            I(i,j)=(I(i,j)-Ibw)/(Ihigh-Ibw)*255;
        end
    end
end
out=I;