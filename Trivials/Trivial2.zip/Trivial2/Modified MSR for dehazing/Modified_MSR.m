vargin='liahthouse.png';
I=image_load(vargin);
% ��ȡRGBͨ��
if ndims(I)==3
    Ir=double(I(:,:,1));
    Ig=double(I(:,:,2));
    Ib=double(I(:,:,3));
else
    Ir=double(I);
    Ig=Ir;
    Ib=Ig;
end
%*****************************��ǿ��Եϸ��***********************************
Irr=detail_enhance(Ir);
Igg=detail_enhance(Ig);
Ibb=detail_enhance(Ib);
%*******************************SSR����*************************************
Rr=ssr(Irr);
Rg=ssr(Igg);
Rb=ssr(Ibb);
%*****************************��Ϻ�����ǿ***********************************
Rr=match_enhance(Rr);
Rg=match_enhance(Rg);
Rb=match_enhance(Rb);
II=cat(3,Rr,Rg,Rb);
imshow(II/255)