function R=ssr(I)
% ���ɸ�˹����
sigma=80;
F=fspecial('gaussian',[3*sigma,3*sigma],sigma);
% 
L=imfilter(I,F,'replicate','conv');
G=log(I+1)-log(L+1);
Min=min(min(G));
Max=max(max(G));
R=(G-Min)*255/(Max-Min);
R(find(R>255))=255;
R(find(R<0))=0;
