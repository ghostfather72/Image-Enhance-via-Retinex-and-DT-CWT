%clc,clear
% Load image
%vargin = load_vargin;
%I = image_load(vargin{2});
I = imread('Original2.png');
ref = imread('Reference2.png');
%figure,imshow(I)
% Transform RGB image to HSV space
[H, S, V] = rgb2hsv(I); % Hue, Saturation and Value layers

% Details enhancement process using Laplacian operator
%lap = [-1 -1 -1; -1 8 -1; -1 -1 -1];
lap=[0 -1 0; -1 4 -1; 0 -1 0];
G = imfilter(V, lap, 'replicate', 'conv');
k = 0.05; % Set the positive parameter
V = abs(V + k * G);
V = (V - min(min(V))) / (max(max(V)) - min(min(V)));

% One layer decomposition using Dual-tree real wavelet transform
[Faf, Fsf] = FSfarras; % set decomposition and recover parameters
[af, sf] = dualfilt1;
J = 1;
w = dualtree2D(V, J, Faf, af);

% Processing the HF signal
%T = 40 / 255;
for j = 1 : J
    for s1 = 1 : 2
        for s2 = 1 : 3
            D = w{j}{s1}{s2};
            D = HFEnphasizeFilter(D);
            %D = soft(D, T);
            w{j}{s1}{s2} = D;
        end
    end
end

% Processing the LF signal using algorithm of this paper:
for s = 1 : 2
    C = w{J + 1}{s};
    Max_w = max(max(C));
    C = C / Max_w * 255;
    %wout = novel_retinex_method(C);
    wout = altm_method(C);
    w{J + 1}{s} = wout / max(max(wout)) * Max_w;
end

% Inverse transformation
V = idualtree2D(w, J, Fsf, sf);


% Image synthesis
[a1, b1] = size(V);
[a2, b2] = size(H);
if a1 ~= a2 || b1 ~= b2
    V = imresize(V, [a2, b2]);
end
hsv = cat(3, H, S, V);

% Transform HSV image to RGB space
rgb = hsv2rgb(hsv);
%rgb = SimplestColorBalance(rgb, 0.04);
%figure, imshow([double(I) / 255, rgb])
%figure, imshow(double(I)/255),title('Original')
%figure,imshow([double(I)/255 rgb / 255])
figure,imshow(rgb )
[SSIMVAL, ~] = ssim(uint8(rgb*255), uint8(ref))