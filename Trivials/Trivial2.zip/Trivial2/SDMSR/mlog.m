function out=mlog(in)
%[~,D]=getrangefromclass(in);
D=256;
Th=240;
wl=Th/(D-1)*log(D)/log(Th+1);
wh=(1-Th/(D-1))*log(D)/log(D-Th);
[m,n]=size(in);
out=zeros(m,n);
for i=1:m
    for j=1:n
        if in(i,j)<=Th
            out(i,j)=wl*log(in(i,j)+1);
        else
            out(i,j)=-wh*log(D-in(i,j))+log(D);
        end
    end
end