%%%%%%
clc
clear
vargin = 'balls.png';
I = image_load(vargin);
[H, S, V] = rgb2hsv(I);

[Faf, Fsf] = FSfarras; % set decomposition and recover parameters
[af, sf] = dualfilt1;
J = 1;
w = dualtree2D(V, J, Faf, af);

V = idualtree2D(w, J, Fsf, sf);

[a1, b1] = size(V);
[a2, b2] = size(H);
if a1 ~= a2 || b1 ~= b2
    V = imresize(V, [a2, b2]);
end
hsv = cat(3, H, S, V);

% Transform HSV image to RGB space
rgb = hsv2rgb(hsv);
figure, imshow([double(I) / 255, rgb])
