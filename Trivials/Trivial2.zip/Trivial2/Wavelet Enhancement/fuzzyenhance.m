function out=fuzzyenhance(in)
[m,n]=size(in);
x_max=max(max(abs(in)));
x_min=min(min(abs(in)));
D=x_max-x_min;
Pmn=zeros(m,n);
P=zeros(m,n);
out=zeros(m,n);
t=1.5;
for i=1:m
    for j=1:n
        Pmn(i,j)=sin(pi/2*(1-(x_max-abs(in(i,j)))/D));
        temp=Pmn(i,j)^(t-1);
        if temp<0.5
            P(i,j)=2^(t-1)*Pmn(i,j)^t;
        else
            P(i,j)=1-2^(t-1)*(1-Pmn(i,j))^t;
        end
        out(i,j)=x_max*(1-2*asin(P(i,j))/pi);
    end
end