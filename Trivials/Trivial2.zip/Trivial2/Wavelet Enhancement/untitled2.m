vargin='horses.png';
I=image_load(vargin);
% Transform RGB image to HSV space
[H,S,V]=rgb2hsv(I);% Hue, Saturation, Value
%****************************Value Layer Process***************************
% ��value�������ɢDaub5/3С���任
[LL,HL,LH,HH]=dwt2(V,'haar');
figure,imshow(LL)
%��Ƶ��Ϣ����
LLbf=bilateralFilter(LL);
k=0.05;
LLr=LL-k*LLbf;
a=2.5;
figure,imshow(LLr)
LLr=2*atan(a*LLr)/pi;% Sigmoid function
LLr=adapthisteq(LLr);
figure,imshow(LLr)

%��Ƶ��Ϣ����
e1=min(min(HL));
e2=max(max(HL));
t=(e1+e2)/2;
k=2;
[m,n]=size(HL);
for i=1:m
    for j=1:n
        if HL(i,j)<t
            HL(i,j)=e1+(t-e1)*((HL(i,j)-e1)/(t-e1))^k;
        else
            HL(i,j)=e2-(e2-t)*((e2-HL(i,j))/(e2-t))^k;
        end
    end
end
e1=min(min(LH));
e2=max(max(LH));
t=(e1+e2)/2;
k=2;
[m,n]=size(LH);
for i=1:m
    for j=1:n
        if LH(i,j)<t
            LH(i,j)=e1+(t-e1)*((LH(i,j)-e1)/(t-e1))^k;
        else
            LH(i,j)=e2-(e2-t)*((e2-LH(i,j))/(e2-t))^k;
        end
    end
end
e1=min(min(HH));
e2=max(max(HH));
t=(e1+e2)/2;
k=2;
[m,n]=size(HH);
for i=1:m
    for j=1:n
        if HH(i,j)<t
            HH(i,j)=e1+(t-e1)*((HH(i,j)-e1)/(t-e1))^k;
        else
            HH(i,j)=e2-(e2-t)*((e2-HH(i,j))/(e2-t))^k;
        end
    end
end
%��value�������ɢDaub5/3С�����任
Vr=idwt2(LLr,HLr,LHr,HHr,'haar');
Srgb=hsv2rgb(cat(3,H,S,Vr));
%figure,imshow(Srgb)