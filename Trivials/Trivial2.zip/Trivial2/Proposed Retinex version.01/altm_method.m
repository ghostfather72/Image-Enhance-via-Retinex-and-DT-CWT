function Lout=altm_method(Lw)

Lwmax = max(max(Lw));% the maximum luminance value
[m, n] = size(Lw);
Lwaver = exp(sum(sum(log(0.001 + Lw))) / (m * n));% log-average luminance
Lg = log(Lw / Lwaver + 1) / log(Lwmax / Lwaver + 1);

% Local Adaptation
Hg = guidedfilter(Lg, Lg, 10, 0.01);

eta = 36;
alpha = 1 + eta * Lg / max(max(Lg));
Lgaver = exp(sum(sum(log(0.001 + Lg))) / (m * n));
lambda = 10;
beta = lambda * Lgaver;

Lout = alpha .* log(Lg ./ Hg + beta);
Min = min(min(Lout));
Max = max(max(Lout));
Lout = (Lout - Min) * 255 / (Max - Min);
Lout(find(Lout > 255)) = 255;
Lout(find(Lout < 0)) = 0;