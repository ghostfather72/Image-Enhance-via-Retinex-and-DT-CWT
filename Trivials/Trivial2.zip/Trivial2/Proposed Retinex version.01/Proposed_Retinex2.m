clc,clear
% Load image
vargin = 'whitehouse.png';
I = image_load(vargin);
%figure,imshow(I)
Ir=double(I(:,:,1));
Ig=double(I(:,:,2));
Ib=double(I(:,:,3));

% Global Adaptation
Lw=0.299*Ir+0.587*Ig+0.114*Ib;% input world luminance values

%Transforming the value layer using "haar" wavelet(one layer of decomposition)
[ll, hl, lh, hh] = dwt2(Lw, 'haar');

% Processing the LF signal using algorithm of this paper:
% <Adaptive Local Tone Mapping Based on Retinex for High Dynamic Range Images>
Max_ll = max(max(ll)); % Getting maximum of ll
ll = ll / Max_ll * 255; % Remapping the range of ll
llout = altm_method(ll); % ALTM method
llout = llout / max(max(llout)) * Max_ll; % Remapping

% Processing the HF signal


% Inverse transformation of wavelet
Lout = idwt2(llout, hl, lh, hh, 'haar');
Lout(find(Lout > 255)) = 255;
Lout(find(Lout < 0)) = 0;
% Details enhancement process
%k = 0.1; % Set the positive parameter
%lap = [-1 -1 -1; -1 8 -1; -1 -1 -1]; % Laplacian operator
%G = imfilter(Lout, lap, 'replicate', 'conv'); % Get the border of the image
%Lout = Lout + k * G;
%Lout(find(Lout > 255)) = 255;
%Lout(find(Lout < 0)) = 0;
% Restoration
gain = Lout ./ Lw;
[m, n] = size(gain);
for i = 1 : m
    for j = 1 : n
        if Lw(i,j) == 0
            gain(i,j) = Lout(i,j);
            %gain(i,j)=255;
        end
    end
end
Irout=gain.*Ir;
Igout=gain.*Ig;
Ibout=gain.*Ib;
altmr=cat(3,Irout,Igout,Ibout);
figure,imshow(uint8(altmr))