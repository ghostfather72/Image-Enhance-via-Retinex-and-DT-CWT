%clc,clear
% Load image
addpath(genpath('ImageGuidedFilter'));
addpath(genpath('DT-CWT'));
vargin = 'whitehouse.png';
I = image_load(vargin);
figure,imshow(I)
% Transform RGB image to HSV space
[H, S, V] = rgb2hsv(I); % Hue, Saturation and Value layers

% Details enhancement process using Laplacian operator
%lap = [-1 -1 -1; -1 8 -1; -1 -1 -1];
%G = imfilter(V, lap, 'replicate', 'conv');
%k = 0.1; % Set the positive parameter
%V = abs(V + k * G);
%V = (V - min(min(V))) / (max(max(V)) - min(min(V)));

% One layer decomposition using Dual-tree complex wavelet transform
[Faf, Fsf] = FSfarras; % set decomposition and recover parameters
[af, sf] = dualfilt1;
J = 1;
w = cplxdual2D(V, J, Faf, af);

% Processing the HF signal
%I = sqrt(-1);
%T = 40 / 255;
%for j = 1:J
    % loop thru subbands
%    for s1 = 1:2
%        for s2 = 1:3
%            C = w{j}{1}{s1}{s2} + I*w{j}{2}{s1}{s2};
%            C = soft(C,T);
%            w{j}{1}{s1}{s2} = real(C);
%            w{j}{2}{s1}{s2} = imag(C);
%        end
%    end
%end

% Processing the LF signal using algorithm of this paper:
I = sqrt(-1);
%for s1 = 1:2
    for s2 = 1:2
        C = w{J + 1}{1}{s2}+I*w{J+1}{2}{s2};
        Max_ww = max(max(C));
        %C = C / Max_ww * 255;
        %wwout = novel_retinex_method(C);
        wwout = altm_method(C);
        %w{J + 1}{s1}{s2} = wwout / max(max(wwout)) * Max_ww;
        C = wwout / max(max(wwout)) * Max_ww;
        w{J+1}{1}{s2} = real(C);
        w{J+1}{2}{s2} = imag(C);
    end
%end

% Inverse transformation of wavelet
V = icplxdual2D(w, J, Fsf, sf); 
% Image synthesis
[a1, b1] = size(V);
[a2, b2] = size(H);
if a1 ~= a2 || b1 ~= b2
    V = imresize(V, [a2, b2]);
end
hsv = cat(3, H, S, V);

% Transform HSV image to RGB space
rgb = hsv2rgb(hsv);
figure,imshow(rgb)
rmpath 'DT-CWT'
rmpath 'ImageGuidedFilter'