addpath(genpath('ImageGuidedFilter'));
addpath(genpath('DT-CWT'));
%clc,clear
% Load image
vargin = 'liahthouse.png';
I = image_load(vargin);

% Transform RGB image to HSV space
[H, S, V] = rgb2hsv(I); % Hue, Saturation and Value layers
V = V * 255;

% Details enhancement process using Laplacian operator
lap = [-1 -1 -1; -1 8 -1; -1 -1 -1];
G = imfilter(V, lap, 'replicate', 'conv');
k = 0.1; % Set the positive parameter
V = V + k * G;
%V(find(V > 255)) = 255;
%V(find(V < 0)) = 0;

% One layer decomposing the value layer using "haar" wavelet
[ll, hl, lh, hh] = dwt2(V, 'haar');

% Processing the LF signal using algorithm of this paper:
Max_ll = max(max(ll));
ll = ll / Max_ll * 255; % Remapping the range of ll
ll = novel_retinex_method(ll); % Novel Retinex method
ll = ll / max(max(ll)) * Max_ll;

% Processing the HF signal

% Inverse transformation of wavelet
V = idwt2(ll, hl, lh, hh, 'haar');
V(find(V > 255)) = 255;
V(find(V < 0)) = 0;
V = V / max(max(V));

% Image synthesis
[a1, b1] = size(V);
[a2, b2] = size(H);
if a1 ~= a2 || b1 ~= b2
    V = imresize(V, [a2, b2]);
end
hsv = cat(3, H, S, V);

% Transform HSV image to RGB space
rgb = hsv2rgb(hsv);
figure,imshow(rgb),title('Version 01')
% Show images and their histogram
% I is uint8 format, rgb is double format which range is [0, 1]
%vargin = 'Proposed Retinex';
%image_info_plot(I, rgb, vargin);

% Evaluating the enhanced result
%evaluation_results = image_evaluate(rgb*255, I)