function altmr=ALTM_Retinex(I)
%vargin=('liahthouse.png');
%I=image_load(vargin);
%figure,imshow(I),title('Original Image')
%figure,Histogram(I);title('Statistic Histogram of Original Image')
Ir=double(I(:,:,1));
Ig=double(I(:,:,2));
Ib=double(I(:,:,3));

% Global Adaptation
Lw=0.299*Ir+0.587*Ig+0.114*Ib;% input world luminance values

%figure,imshow(Lw/255)%,title('Luminance')
%[m,n]=size(Lw);
%figure,hist(reshape(Lw,1,m*n),255);

Lwmax=max(max(Lw));% the maximum luminance value
[m,n]=size(Lw);
Lwaver=exp(sum(sum(log(0.001+Lw)))/(m*n));% log-average luminance
Lg=log(Lw/Lwaver+1)/log(Lwmax/Lwaver+1);
%figure,imshow(Lg)%,title('Global Adaptation Output')

% Local Adaptation
Hg=guidedfilter(Lg,Lg,10,0.01);
%figure,imshow(Hg)
Li=log(Lg*255+1)-log(Hg*255+1);

eta=36;
alpha=1+eta*Lg/max(max(Lg));
Lgaver=exp(sum(sum(log(0.001+Lg)))/(m*n));
lambda=10;
beta=lambda*Lgaver;

Lout=alpha.*log(Lg./Hg+beta);
Min=min(min(Lout));
Max=max(max(Lout));
Lout=(Lout-Min)*255/(Max-Min);
n_b=find(Lout>255);
Lout(n_b)=255;
m_b=find(Lout<0);
Lout(m_b)=0;

%figure,imshow(Lout/255)%,title('Final Local Adaptation Output')
%figure,hist(reshape(Lout,1,m*n),255);
gain=Lout./Lw;
[m,n]=size(gain);
for i=1:m
    for j=1:n
        if Lw(i,j)==0
            gain(i,j)=Lout(i,j);
            %gain(i,j)=255;
        end
    end
end
Irout=gain.*Ir;
Igout=gain.*Ig;
Ibout=gain.*Ib;
altmr=cat(3,Irout,Igout,Ibout);
%figure,imshow(altmr/255),title('ALTM Retinex Output')
%figure,Histogram(altmr);title('Statistic Histogram of the Output')