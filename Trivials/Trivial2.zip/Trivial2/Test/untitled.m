vargin{1} = 'whitehouse.png';
vargin{2} = 'liahthouse.png';
vargin{3} = 'horses.png';
vargin{4} = 'house.png';
vargin{5} = 'lena.png';
name = 'msrcp_';
figure,
for i = 1 : 5
    I = image_load(vargin{i});
    subplot(5,5,5 * (i - 1) + 1)
    imshow(I), title('Original'), xlabel('(a)'), ylabel(vargin{i}(1, 1 : end - 4))
    subplot(5,5,5 * (i - 1) + 2)
    ssr = SSR(I);
    imshow(uint8(ssr)),title('SSR,\sigma=80'),xlabel('(b)')
    subplot(5,5,5 * (i - 1) + 3)
    msr = MSR(I);
    imshow(uint8(msr)),title('MSR,\sigma=15,80,250'),xlabel('(c)')
    subplot(5,5,5 * (i - 1) + 4)
    msrcr = MSRCR(I);
    imshow(uint8(msrcr)),title(MSRCR),xlabel('(d)')
    subplot(5,5,5 * (i - 1) + 5)
    imshow(imread([name vargin{i}(1, 1 : end - 4)])), title('MSRCP'), xlabel('(e)')
end