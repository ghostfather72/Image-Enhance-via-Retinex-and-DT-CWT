vargin='liahthouse.png';
I=image_load(vargin);

ssr=SSR(I);
msr=MSR(I);
msrcr=MSRCR_Original(I);
msrcp=MSRCP(I);
altmr=ALTM_Retinex(I);
ltmsdmsr=LTM_SDMSR(I);
rgb=Novel_Retinex(I);

figure,
subplot(3,4,1)
imshow(imresize(I, 0.5)), title('Original Image')
subplot(3,4,2)
imhist(double(I(:,:,1)) / 255);
hold on
imhist(double(I(:,:,2)) / 255);
imhist(double(I(:,:,3)) / 255);
title('Original Image')
hold off

subplot(3,4,3)
imshow(imresize(msrcr/255, 0.5)), title('MSRCR')
subplot(3,4,4)
imhist(msrcr(:,:,1)/255);
hold on
imhist(msrcr(:,:,2)/255);
imhist(msrcr(:,:,3)/255);
title('MSRCR')
hold off

subplot(3,4,5)
imshow(imresize(msrcp/255, 0.5)), title('MSRCP')
subplot(3,4,6)
imhist(msrcp(:,:,1)/255);
hold on
imhist(msrcp(:,:,2)/255);
imhist(msrcp(:,:,3)/255);
title('MSRCP')
hold off

subplot(3,4,7)
imshow(imresize(altmr/255, 0.5)), title('ALTM Retinex')
subplot(3,4,8)
imhist(altmr(:,:,1)/255);
hold on
imhist(altmr(:,:,2)/255);
imhist(altmr(:,:,3)/255);
title('ALTM Retinex')
hold off

subplot(3,4,9)
imshow(imresize(ltmsdmsr/255, 0.5)), title('LTM-SDMSR')
subplot(3,4,10)
imhist(ltmsdmsr(:,:,1)/255);
hold on
imhist(ltmsdmsr(:,:,2)/255);
imhist(ltmsdmsr(:,:,3)/255);
title('LTM-SDMSR')
hold off

subplot(3,4,11)
imshow(imresize(rgb/255, 0.5)), title('Novel Retinex')
subplot(3,4,12)
imhist(rgb(:,:,1)/255);
hold on
imhist(rgb(:,:,2)/255);
imhist(rgb(:,:,3)/255);
title('Novel Retinex')
hold off