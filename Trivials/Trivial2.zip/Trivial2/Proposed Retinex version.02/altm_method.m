function outval = altm_method(Lw)
Lwmax = max(max(Lw));% the maximum luminance value
[m, n] = size(Lw);
Lwaver = exp(sum(sum(log(0.001 + Lw))) / (m * n));% log-average luminance
Lg = log(Lw / Lwaver + 1) / log(Lwmax / Lwaver + 1);

% Local Adaptation
kenlRatio = 0.01;
krnlsz = floor(max([3, m*kenlRatio, n*kenlRatio]));
Lg1 = maxfilt2(Lg, [krnlsz,krnlsz]);
Lg1 = imresize(Lg1, [m, n]);
Hg = guidedfilter(Lg, Lg1, 10, 0.01);


eta = 36;
alpha = 1 + eta * Lg / max(max(Lg));
alpha = alpha .* (alpha .^ (1.5 ./ alpha));
max_alpha = max(max(alpha));
a = 1.2;
alpha = 2 * atan(a * alpha / max_alpha) / pi * max_alpha;

Lgaver = exp(sum(sum(log(0.001 + Lg))) / (m * n));
lambda = 10;
beta = lambda * Lgaver;

Lout = alpha .* log(Lg ./ Hg + beta);
Min = min(min(Lout));
Max = max(max(Lout));
Lout = (Lout - Min) * Lwmax / (Max - Min);
Lout(find(Lout > Lwmax)) = Lwmax;
Lout(find(Lout < 0)) = 0;
outval = Lout;
%outval = SimplestColorBalance(Lout, 0.01, 0.02);
