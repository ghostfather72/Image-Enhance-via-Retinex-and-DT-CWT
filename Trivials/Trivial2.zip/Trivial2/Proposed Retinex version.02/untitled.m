vargin = 'liahthouse.png';
I = image_load(vargin);

% Transform RGB image to HSV space
[H, S, V] = rgb2hsv(I); % Hue, Saturation and Value layers

% Details enhancement process using Laplacian operator
lap = [-1 -1 -1; -1 8 -1; -1 -1 -1];
G = imfilter(V, lap, 'replicate', 'conv');
k = 0.1; % Set the positive parameter
V = abs(V + k * G);
V = (V - min(min(V))) / (max(max(V)) - min(min(V)));
V = V * 255;

alpha = 10;
beta = 0.15;
gamma = 0.001;
a = 0.04;
maxIter = 4; % Seting the maximal iterations

% Seting the Gaussian kernel and mask
[m, n] = size(V);

% Computing L0 and initialization L using Gaussian low-pass filter
L = guidedfilter(V / 255, V / 255, 10, 1);
L = L * 255;
L0 = L;

% Initialization R
R = V ./ L;
%R = R / max(max(R));


% Seting the edge detection operator
hx = fspecial('Sobel'); % horizontal direction
hy = hx'; % vertical direction

% Iteration
for iter = 1 : maxIter
    % Geting the horizontal map of R
    DxR = abs(imfilter(R, hx, 'replicate', 'conv'));
    % Geting the vertical map of R
    DyR = abs(imfilter(R, hy, 'replicate', 'conv'));
    % updating L by component-wise
    for i = 1 : m
        for j = 1 : n
            mole = fft(V(i,j) / L(i,j));
            deno = fft(1) + beta * (conj(fft(DxR(i,j))) * fft(DxR(i,j)) + ...
                conj(fft(DyR(i,j))) * fft(DyR(i,j)));
            R(i,j) = ifft(mole / deno);
            R(i,j) = min(1, max(R(i,j), 0)); % Normalization process
        end
    end
    % Geting the horizontal map of L
    DxL = abs(imfilter(L, hx, 'replicate', 'conv'));
    % Geting the vertical map of L
    DyL = abs(imfilter(L, hy, 'replicate', 'conv'));
    % updating L by component-wise
    for i = 1 : m
        for j = 1 : n
            mole = fft(gamma * L0(i,j) + V(i,j) / R(i,j));
            deno = fft(1 + gamma) + alpha * (conj(fft(DxL(i,j))) * ...
                fft(DxL(i,j)) + conj(fft(DyL(i,j))) * fft(DyL(i,j)));
            L(i,j) = ifft(mole / deno);
            L(i,j) = max(L(i,j), V(i,j));
        end
    end
end
% Illumination adjustment is adopted to enhance L
L_adjusted = 2 * atan(a * L) / pi; % Sigmoid function
L_final = adapthisteq(L_adjusted, 'NumTiles', [8, 8], 'ClipLimit', 0.02,...
    'NBins', 256 ,'Range', 'full', 'Distribution', 'rayleigh', 'Alpha', 0.5);

% Reflectance adjustment is adopted to ehchance R,
% after study the features of R, we find that all the values of R
% is near to 1, so, we just set R as ones matrix
%R = ones(size(L));
R = guidedfilter(R, R, 10, 0.4);

% Synthesizing the R and L
img = R .* L_final;

hsv = cat(3, H, S, img);

% Transform HSV image to RGB space
rgb = hsv2rgb(hsv);