vargin = 'lena.png';
I = image_load(vargin);
%I = double(rgb2gray(I));
I = double(I(:,:,2));
%I = double(I(:,:,3));

[Faf, Fsf] = FSfarras; % set decomposition and recover parameters
[af, sf] = dualfilt1;
w = cplxdual2D(I, 1, Faf, af);

%1-real
C = w{2}{1}{1};
max(max(C))
figure,
subplot(221),imshow(C / max(max(C)))
wout = altm_method(C);
subplot(222),imshow(wout / max(max(wout)))
%1-imag
C = w{2}{2}{1};
max(max(C))
subplot(223),imshow(C / max(max(C)))
wout = altm_method(C);
subplot(224),imshow(wout / max(max(wout)))

%2-real
C = w{2}{1}{2};
max(max(C))
figure,
subplot(221),imshow(C / max(max(C)))
wout = altm_method(C);
subplot(222),imshow(wout / max(max(wout)))
%2-imag
C = w{2}{2}{2};
max(max(C))
subplot(223),imshow(C / max(max(C)))
wout = altm_method(C);
subplot(224),imshow(wout / max(max(wout)))