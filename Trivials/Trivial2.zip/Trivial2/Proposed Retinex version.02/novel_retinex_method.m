% This is the implementation of the paper:
% <A Novel Retinex Based Approach for Image Enhancement... 
% with Illumination Adjustment>
function img = novel_retinex_method(I)
% Seting fixed parameters
alpha = 10;
beta = 0.15;
gamma = 0.001;
a = 0.04;
maxIter = 4; % Seting the maximal iterations

% Seting the Gaussian kernel and mask
[m, n] = size(I);

% Computing L0 and initialization L using Gaussian low-pass filter
L = guidedfilter(I / 255, I / 255, 10, 1);
L = L * 255;
L0 = L;

% Initialization R
R = I ./ L;
%R = R / max(max(R));


% Seting the edge detection operator
hx = fspecial('Sobel'); % horizontal direction
hy = hx'; % vertical direction

% Iteration
for iter = 1 : maxIter
    % Geting the horizontal map of R
    DxR = abs(imfilter(R, hx, 'replicate', 'conv'));
    % Geting the vertical map of R
    DyR = abs(imfilter(R, hy, 'replicate', 'conv'));
    % updating L by component-wise
    for i = 1 : m
        for j = 1 : n
            mole = fft(I(i,j) / L(i,j));
            deno = fft(1) + beta * (conj(fft(DxR(i,j))) * fft(DxR(i,j)) + ...
                conj(fft(DyR(i,j))) * fft(DyR(i,j)));
            R(i,j) = ifft(mole / deno);
            R(i,j) = min(1, max(R(i,j), 0)); % Normalization process
        end
    end
    % Geting the horizontal map of L
    DxL = abs(imfilter(L, hx, 'replicate', 'conv'));
    % Geting the vertical map of L
    DyL = abs(imfilter(L, hy, 'replicate', 'conv'));
    % updating L by component-wise
    for i = 1 : m
        for j = 1 : n
            mole = fft(gamma * L0(i,j) + I(i,j) / R(i,j));
            deno = fft(1 + gamma) + alpha * (conj(fft(DxL(i,j))) * ...
                fft(DxL(i,j)) + conj(fft(DyL(i,j))) * fft(DyL(i,j)));
            L(i,j) = ifft(mole / deno);
            L(i,j) = max(L(i,j), I(i,j));
        end
    end
end
% Illumination adjustment is adopted to enhance L
L_adjusted = 2 * atan(a * L) / pi; % Sigmoid function
%L_final = adapthisteq(L_adjusted); % CLAHE method
L_final = adapthisteq(L_adjusted,'ClipLimit',0.02,'Distribution','exponential');

% Reflectance adjustment is adopted to ehchance R,
% after study the features of R, we find that all the values of R
% is near to 1, so, we just set R as ones matrix
%R = ones(size(L));
R = guidedfilter(R, R, 10, 0.2);

% Synthesizing the R and L
img = R .* L_final;