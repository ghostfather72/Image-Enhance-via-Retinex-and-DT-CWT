function Histogram(Img)
R=double(Img(:,:,1));
G=double(Img(:,:,2));
B=double(Img(:,:,3));
[m,n]=size(R);
[HR,XR]=hist(reshape(R,1,m*n),255);
[HG,XG]=hist(reshape(G,1,m*n),255);
[HB,XB]=hist(reshape(B,1,m*n),255);
plot(XR,HR,'-r')
grid on
hold on
plot(XG,HG,'-g')
plot(XB,HB,'-b')
hold off