% This is the changed Local Tone Mapping using Sub-band Decomposed... 
% Multi-scale Retinex, which changes some processing within this algorithm
vargin='whitehouse.png';
I=image_load(vargin);
%vargin='greenwich-reference.png';
%ref=image_load(vargin);
%I = imread('reference2.png');
%figure,imshow(I)
I=double(I);
Ir=I(:,:,1);
Ig=I(:,:,2);
Ib=I(:,:,3);

%alpha1=125;
%beta1=46;
%gain=30;
%offset=-6;
%cut=2.45;

% A. Global Dynamic Range Compression
L=0.299*Ir+0.587*Ig+0.114*Ib;
%figure,imshow(L/255)
%[m,n]=size(L);
%figure,hist(reshape(L,1,m*n),255);
Lmax=max(max(L));
[m,n]=size(L);
Laver=exp(sum(sum(log(0.001+L)))/(m*n));
Lg=log(L/Laver+1)/log(Lmax/Laver+1);
%figure,imshow(Lg)
% B. Local Contrast Enhancement using SD-MSR
r=[5,10,20];
eps=[0.1^2,0.2^2,0.4^2];
H1=guidedfilter(Lg,Lg,r(1),eps(1));
H2=guidedfilter(Lg,Lg,r(2),eps(2));
H3=guidedfilter(Lg,Lg,r(3),eps(3));
%figure,imshow(H1)
%figure,imshow(H2)
%figure,imshow(H3)
eta=36;
alpha=1+eta*Lg/max(max(Lg));
Lgaver=exp(sum(sum(log(0.001+Lg)))/(m*n));
lambda=10;
beta=lambda*Lgaver;
R1=alpha.*log((Lg)./(H1)+beta);
R2=alpha.*log((Lg)./(H2)+beta);
R3=alpha.*log((Lg)./(H3)+beta);
sdR1=R1;
sdR2=R2-R1;
sdR3=R3-R2;
%figure,imshow(normfun(sdR1,1))
%figure,imshow(normfun(sdR2,1))
%figure,imshow(normfun(sdR3,1))
%figure,imshow(sdR1)
%figure,imshow(sdR2)
%figure,imshow(sdR3)
Max=max(max(abs(sdR1)));
NR1=abs(sdR1)/Max;
Max=max(max(abs(sdR2)));
NR2=abs(sdR2)/Max;
Max=max(max(abs(sdR3)));
NR3=abs(sdR3)/Max;
r1=r(1)/max(r);
r2=r(2)/max(r);
r3=r(3)/max(r);
epsilon=0.1;
g1=(1./(NR1+epsilon)).^(1-r1);
g2=(1./(NR2+epsilon)).^(1-r2);
g3=(1./(NR3+epsilon)).^(1-r3);
R=g1.*sdR1+g2.*sdR2+g3.*sdR3;
% ����MSRCR�е���ɫУ������
%C=beta1*(log((Ir+1)*alpha1)-log(Ir+Ig+Ib+3));
%G=gain*(C.*R+offset);
%u=mean2(G);%����ͼ��ľ�ֵ
%s=std2(G);%����
%Min=u-cut*s;%��Сֵ
%Max=u+cut*s;%���ֵ
%R=(G-Min)/(Max-Min);
%R(find(R>1))=1;
%R(find(R<0))=0;
%*************************************
R=normfun(R,1);
%a=3.5;
%R=2*atan(a*R)/pi;% Sigmoid function
R=adapthisteq(R);% CLAHE method

%figure,imshow(R)
%[m,n]=size(Int);
%figure,hist(reshape(R,1,m*n),255);

%color processing
gain=R./(1.15 * L);
[m,n]=size(gain);
for i=1:m
    for j=1:n
        if L(i,j)==0
            gain(i,j)=0;
        end
    end
end
Er=gain.*Ir;
Eg=gain.*Ig;
Eb=gain.*Ib;
%[Er,Eg,Eb]=normfunfinal(Er,Eg,Eb,255);
sdmsr=cat(3,Er,Eg,Eb);
%figure,imshow(sdmsr);%title('LTM-SDMSR after modified')
%outval=easy_evaluate(sdmsr*255,double(I))
%[Er,Eg,Eb]=normfunfinal(Er,Eg,Eb,1);
%sdmsr=cat(3,Er,Eg,Eb);
%figure,Histogram(sdmsr);
imwrite(uint8(sdmsr*255),'ltmsdmsr.png');
%PSNR = psnr(uint8(sdmsr*255), uint8(ref))
%[SSIMVAL, ~] = ssim(uint8(sdmsr*255), uint8(ref))
%[FSIM, ~] = FeatureSIM(uint8(ref), uint8(sdmsr*255))
%sdmsr1 = rgb2gray(uint8(sdmsr*255));
%ref1 = rgb2gray(uint8(ref));
%vif = vifvec(ref1,sdmsr1)