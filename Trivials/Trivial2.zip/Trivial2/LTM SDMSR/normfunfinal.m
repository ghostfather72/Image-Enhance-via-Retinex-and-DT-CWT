function [Er,Eg,Eb]=normfunfinal(R,G,B,num)
Maxr=max(max(R));Maxg=max(max(G));Maxb=max(max(B));
Minr=min(min(R));Ming=min(min(G));Minb=min(min(B));
Max=max(Maxr,max(Maxg,Maxb));
Min=min(Minr,min(Ming,Minb));

Er=num*(R-Min)/(Max-Min);
m_r=find(Er>num);
Er(m_r)=num;
n_r=find(Er<0);
Er(n_r)=0;

Eg=num*(G-Min)/(Max-Min);
m_g=find(Eg>num);
Eg(m_g)=num;
n_g=find(Eg<0);
Eg(n_g)=0;

Eb=num*(B-Min)/(Max-Min);
m_b=find(Eb>num);
Eb(m_b)=num;
n_b=find(Eb<0);
Eb(n_b)=0;