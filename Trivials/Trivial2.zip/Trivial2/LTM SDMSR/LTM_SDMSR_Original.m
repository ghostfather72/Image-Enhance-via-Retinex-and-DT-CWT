vargin='Original2.png';
%I=image_load(vargin);
I = imread(vargin);
%I = imread('Original.png');
%I=im2double(I);%range from 0 to 1
I=double(I);
Ir=I(:,:,1);
Ig=I(:,:,2);
Ib=I(:,:,3);

% A. Global Dynamic Range Compression
L=0.299*Ir+0.587*Ig+0.114*Ib;
Lmax=max(max(L));
[m,n]=size(L);
Laver=exp(sum(sum(log(0.001+L)))/(m*n));
Lg=log(L/Laver+1)/log(Lmax/Laver+1);

% B. Local contrast enhancement using SD-MSR, where Nb=3
r=[10,20,40];
eps=[0.1^2,0.2^2,0.4^2];
H1=guidedfilter(Lg,Lg,r(1),eps(1));
H2=guidedfilter(Lg,Lg,r(2),eps(2));
H3=guidedfilter(Lg,Lg,r(3),eps(3));

R1=mlog(Lg*255)-mlog(H1*255);
R2=mlog(Lg*255)-mlog(H2*255);
R3=mlog(Lg*255)-mlog(H3*255);

sdR1=R1;
sdR2=R2-R1;
sdR3=R3-R2;

Max=max(max(abs(sdR1)));
NR1=abs(sdR1)/Max;
Max=max(max(abs(sdR2)));
NR2=abs(sdR2)/Max;
Max=max(max(abs(sdR3)));
NR3=abs(sdR3)/Max;

r1=r(1)/max(r);
r2=r(2)/max(r);
r3=r(3)/max(r);
epsilon=0.1;
g1=(1./(NR1+epsilon)).^(1-r1);
g2=(1./(NR2+epsilon)).^(1-r2);
g3=(1./(NR3+epsilon)).^(1-r3);

R=g1.*sdR1+g2.*sdR2+g3.*sdR3;
Min=min(min(R));
Max=max(max(R));
R=(R-Min)/(Max-Min);
m_r=find(R>1);
R(m_r)=1;
n_r=find(R<0);
R(n_r)=0;

%color processing
Er=R.*(Ir./L);
Eg=R.*(Ig./L);
Eb=R.*(Ib./L);
%[Er,Eg,Eb]=normfunfinal(Er,Eg,Eb,1);
sdmsr=cat(3,Er,Eg,Eb);
figure,imshow(sdmsr);
%figure,Histogram(sdmsr);