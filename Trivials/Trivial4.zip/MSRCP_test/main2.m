addpath(genpath('Image Evaluate'));
addpath(genpath('PyrTools'));

filename = 'test_images2/';
imorig = 'Original_';
imscb = 'SCB_';

% ��һ��ͼ
orig = double(imread([filename imorig 'dog.png']));
scb = double(imread([filename imscb 'dog.png']));
outval = SimplestColorBalance(orig, 3);
figure, imshow(orig / 255), title('Original Image')
image_plot_SCB(scb, outval)
outval1_dog = image_evaluate(outval, scb)
outval2_dog = image_evaluate2(outval, scb)

% �ڶ���ͼ
orig = double(imread([filename imorig 'fruits.png']));
scb = double(imread([filename imscb 'fruits.png']));
outval = SimplestColorBalance(orig, 3);
figure, imshow(orig / 255), title('Original Image')
image_plot_SCB(scb, outval)
outval1_fruits = image_evaluate(outval, scb)
outval2_fruits = image_evaluate2(outval, scb)

% ������ͼ
orig = double(imread([filename imorig 'house.png']));
scb = double(imread([filename imscb 'house.png']));
outval = SimplestColorBalance(orig, 3);
figure, imshow(orig / 255), title('Original Image')
image_plot_SCB(scb, outval)
outval1_house = image_evaluate(outval, scb)
outval2_house = image_evaluate2(outval, scb)

rmpath 'Image Evaluate'
rmpath 'PyrTools'