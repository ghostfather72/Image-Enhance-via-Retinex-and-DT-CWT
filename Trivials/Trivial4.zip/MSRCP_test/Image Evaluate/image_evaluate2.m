function outval = image_evaluate2(I, Iorg)
% ��ԭͼ��SSIM(Structural SIMilarity index)
[SSIM, ssimmap]=ssim(I, Iorg);

% ��ԭͼ��FSIM(Feature SIMilarity index)
[FSIM, FSIMc] = FeatureSIM(Iorg, I);

% ��ԭͼ��QILV(Quality Index based on Local Variance)
%imorg = rgb2gray(I_original);
%imdist = rgb2gray(I);
%QILV = qilv(imdist, imorg, 0);

% ��ԭͼ��VIF(Visual Information Fidelity)
imorg = rgb2gray(Iorg);
imdist = rgb2gray(I);
VIF = vifvec(imorg, imdist);
outval = [SSIM, FSIM, VIF];