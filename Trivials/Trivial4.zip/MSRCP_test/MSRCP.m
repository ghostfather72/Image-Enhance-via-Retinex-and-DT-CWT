function outval = MSRCP(I)

if ndims(I) == 3
    Ir = double(I(:, :, 1));
    Ig = double(I(:, :, 2));
    Ib = double(I(:, :, 3));
else
    Ir = double(I);
    Ig = double(I);
    Ib = double(I);
end

Int = (Ir + Ig + Ib) / 3;

[m, n] = size(Int);
%if m < n
%    h = m;
%else
%    h = n;
%end

%sigma1 = double(uint8(h * 0.23));%С�ߴ�Ϊͼ���С��3%
%sigma2 = double(uint8(h * 0.43));%�гߴ�Ϊͼ���С��13%
%sigma3 = double(uint8(h * 0.60));%��ߴ�Ϊͼ���С��40%
sigma1 = 15;
sigma2 = 80;
sigma3 = 250;

F1 = fspecial('gaussian', [3 * sigma1, 3 * sigma1], sigma1);
F2 = fspecial('gaussian', [3 * sigma2, 3 * sigma2], sigma2);
F3 = fspecial('gaussian', [3 * sigma3, 3 * sigma3], sigma3);

L1 = imfilter(Int, F1, 'replicate', 'conv');
L2 = imfilter(Int, F2, 'replicate', 'conv');
L3 = imfilter(Int, F3, 'replicate', 'conv');

G = double(1 / 3) * (log(Int + 1) - log(L1 + 1)) +...
    double(1 / 3) * (log(Int + 1) - log(L2 + 1)) +...
    double(1 / 3) * (log(Int + 1) - log(L3 + 1));

Int1 = SimplestColorBalance(G / max(max(G)) * 255, 2);

msrcp_r = zeros(m, n);
msrcp_g = zeros(m, n);
msrcp_b = zeros(m, n);
for i = 1 : m
    for j = 1 : n
        B = max([Ir(i, j), Ig(i, j), Ib(i, j)]);
        A = min(255 / B, Int1(i, j) / Int(i, j));
        if A == inf
            A = 0;
        end
        msrcp_r(i, j) = A * Ir(i, j);
        msrcp_g(i, j) = A * Ig(i, j);
        msrcp_b(i, j) = A * Ib(i, j);
    end
end

outval = cat(3, msrcp_r, msrcp_g, msrcp_b);