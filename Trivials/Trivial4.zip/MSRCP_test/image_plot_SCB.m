function image_plot_SCB(scb, outval)
[m, n, p] = size(scb);
figure,
imshow([scb, 255 * ones(m, 4, p), outval] / 255);
title(['Left: Original SimplestColorBalance,  ',...
    'Right: SimplestColorBalance by Myself'])
figure,
color = {'R','G','B'};
for i = 1:p
    scb_hist = reshape(double(scb(:, :, i)), [1, m * n]);
    subplot(3, 2, 2 * i - 1)
    hist(scb_hist, 256)
    set(findobj(gca,'Type','patch'),'FaceColor',color{i},...
            'EdgeColor',color{i})
    xlim([0 255])
    title(['Original SimplestCB Hist. of ' color{i} ' Channel'])
    
    outval_hist = reshape(double(outval(:, :, i)), [1, m * n]);
    subplot(3, 2, 2 * i)
    hist(outval_hist, 256)
    set(findobj(gca,'Type','patch'),'FaceColor',color{i},'EdgeColor',color{i})
    xlim([0 255])
    title(['SimplestCB by Self Hist. of ' color{i} ' Channel'])
end