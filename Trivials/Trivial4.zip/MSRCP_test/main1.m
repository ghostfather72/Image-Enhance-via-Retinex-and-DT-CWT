

filename = 'test_images1/';
imorig = 'Original_';
immsrcr = 'MSRCR_';
immsrcp = 'MSRCP_';

% ��һ��ͼ
orig = double(imread([filename imorig 'balls.png']));
msrcr = double(imread([filename immsrcr 'balls.png']));
msrcp = double(imread([filename immsrcp 'balls.png']));
outval = MSRCP(orig);
image_plot(orig, msrcr, msrcp, outval)

% �ڶ���ͼ
orig = double(imread([filename imorig 'ceiling.png']));
msrcr = double(imread([filename immsrcr 'ceiling.png']));
msrcp = double(imread([filename immsrcp 'ceiling.png']));
outval = MSRCP(orig);
image_plot(orig, msrcr, msrcp, outval)

% ������ͼ
orig = double(imread([filename imorig 'cathedral.png']));
msrcr = double(imread([filename immsrcr 'cathedral.png']));
msrcp = double(imread([filename immsrcp 'cathedral.png']));
outval = MSRCP(orig);
image_plot(orig, msrcr, msrcp, outval)

% ������ͼ
orig = double(imread([filename imorig 'horses.png']));
msrcr = double(imread([filename immsrcr 'horses.png']));
msrcp = double(imread([filename immsrcp 'horses.png']));
outval = MSRCP(orig);
image_plot(orig, msrcr, msrcp, outval)

% ������ͼ
orig = double(imread([filename imorig 'iris.png']));
msrcr = double(imread([filename immsrcr 'iris.png']));
msrcp = double(imread([filename immsrcp 'iris.png']));
outval = MSRCP(orig);
image_plot(orig, msrcr, msrcp, outval)

% ������ͼ
orig = double(imread([filename imorig 'liahthouse.png']));
msrcr = double(imread([filename immsrcr 'liahthouse.png']));
msrcp = double(imread([filename immsrcp 'liahthouse.png']));
outval = MSRCP(orig);
image_plot(orig, msrcr, msrcp, outval)

% ������ͼ
orig = double(imread([filename imorig 'whitehouse.png']));
msrcr = double(imread([filename immsrcr 'whitehouse.png']));
msrcp = double(imread([filename immsrcp 'whitehouse.png']));
outval = MSRCP(orig);
image_plot(orig, msrcr, msrcp, outval)