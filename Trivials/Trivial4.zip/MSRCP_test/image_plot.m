function image_plot(orig, msrcr, msrcp, outval)
[m, n, p] = size(orig);
figure,
imshow([orig, 255 * ones(m, 4, p), msrcr;
        255 * ones(4, n + n + 4, p);
        msrcp, 255 * ones(m, 4, p), outval] / 255);
title(['Top Left: Original,  Top Right: MSRCR,',...
    '  Bottom Left: Original MSRCP,  Bottom Right: MSRCP'])
figure,
color = {'R','G','B'};
for i = 1:p
    msrcp_hist = reshape(double(msrcp(:, :, i)), [1, m * n]);
    subplot(3, 2, 2 * i - 1)
    hist(msrcp_hist, 256)
    set(findobj(gca,'Type','patch'),'FaceColor',color{i},...
            'EdgeColor',color{i})
    xlim([0 255])
    title(['Original MSRCP Hist. of ' color{i} ' Channel'])
    outval_hist = reshape(double(outval(:, :, i)), [1, m * n]);
    subplot(3, 2, 2 * i)
    hist(outval_hist, 256)
    set(findobj(gca,'Type','patch'),'FaceColor',color{i},'EdgeColor',color{i})
    xlim([0 255])
    title(['MSRCP Hist. of ' color{i} ' Channel'])
end