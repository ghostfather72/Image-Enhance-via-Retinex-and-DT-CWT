%simplestColorBalance(filename,outFile,satLevel,plot)
% Performs color balancing via histogram normalization.
% satLevel controls the percentage of pixels to clip to white and black.
% Set plot = 0 or 1 to turn diagnostic plots on or off.
vargin = 'dog.png';
im_orig = image_load(vargin);

 figure
 imshow(im_orig)
% title('Original Image')



% full width histogram method
satLevel = .03; %percentage of the image to saturate to black or white, tweakable param
q = [satLevel/2 1-satLevel/2];

%imRGB_orig = cbreshape(im_orig)*255;

% ʵ��cbreshape
[m, n, o] = size(im_orig);
imRGB_orig = zeros(o, m * n);
for i = 1:o
    imRGB_orig(i,:) = reshape(double(im_orig(:,:,i)),[1, m*n]); 
end



imRGB = zeros(size(imRGB_orig));
N = size(imRGB_orig,2);
color = {'r','g','b'};
figure,
for ch = 1:3
    
    
    subplot(2,3,ch)
    hist(imRGB_orig(ch,:),256)
    set(findobj(gca,'Type','patch'),'FaceColor',color{ch},...
        'EdgeColor',color{ch})
    xlim([0 255])
    title('Original Histogram')
        
    tiles = quantile(imRGB_orig(ch,:),q);
%     [sum(imRGB_orig(ch,:)<tiles(1))/N,sum(imRGB_orig(ch,:)>tiles(2))/N] %check percentages are correct
    %imRGB(ch,:) = cbsaturate(imRGB_orig(ch,:),tiles); %saturate at the appropriate pts. in distribution
    % ʵ��cbsaturate
    temp = imRGB_orig(ch, :);
    temp(find(temp < tiles(1))) = tiles(1);
    temp(find(temp > tiles(2))) = tiles(2);
    imRGB(ch, :) = temp;
    
    bottom = min(imRGB(ch,:)); top = max(imRGB(ch,:));
    imRGB(ch,:) = (imRGB(ch,:)-bottom)*255/(top-bottom);
    
    
    subplot(2,3,ch+3)
    hist(imRGB(ch,:),256)
    set(findobj(gca,'Type','patch'),'FaceColor',color{ch},...
        'EdgeColor',color{ch})
    xlim([0 255])
    title('Corrected Histogram')
    
    %print(gcf,'-dpng',[outFile '-fig' num2str(ch)])
end
%imwrite(cbunshape(imRGB,size(im_orig))/255,outFile,'png');
% ʵ��cbunshape
RGB=zeros(size(im_orig));
for i = 1:o
    RGB(:,:,i) = reshape(imRGB(i,:),[m, n]); 
end
figure,imshow(RGB/255)
% figure
% imshow(cbunshape(imRGB,size(im_orig))/255)
% title('Simplest Color Balance Corrected')